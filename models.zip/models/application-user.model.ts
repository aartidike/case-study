import { Model, PrimaryKey, Column, DataType, Table, UpdatedAt, CreatedAt } from "sequelize-typescript";

/**
 * Class ApplicationUser Model
 *
 * @export
 * @class ApplicationUser
 * @extends {Model<ApplicationUser>}
 */
@Table({ tableName: "ApplicationUsers", freezeTableName: true, timestamps: true, schema: "" })
export class ApplicationUser extends Model<ApplicationUser> {
    /**
     * userId
     *
     * @type {number}
     * @memberof ApplicationUser
     */

    @PrimaryKey
    @Column({ field: "UserId", type: DataType.NUMBER })
    userId: number;

    /**
     * globalUserId
     *
     * @type {string}
     * @memberof ApplicationUser
     */

    @Column({ field: "GlobalUserId", type: DataType.STRING })
    globalUserId: string;

    /**
     * isActive
     *
     * @type {number}
     * @memberof ApplicationUser
     */

    @Column({ field: "IsActive", type: DataType.NUMBER })
    isActive: number;

    /**
     * createdBy
     *
     * @type {string}
     * @memberof ApplicationUser
     */

    @Column({ field: "CreatedBy", type: DataType.STRING })
    createdBy: string;

    /**
     * createdOn
     *
     * @type {Date}
     * @memberof ApplicationUser
     */

    @CreatedAt
    @Column({ field: "CreatedOn", type: DataType.DATE })
    createdOn: Date;

    /**
     * updatedBy
     *
     * @type {string}
     * @memberof ApplicationUser
     */

    @Column({ field: "UpdatedBy", type: DataType.STRING })
    updatedBy: string;

    /**
     * updatedOn
     *
     * @type {Date}
     * @memberof ApplicationUser
     */

    @UpdatedAt
    @Column({ field: "UpdatedOn", type: DataType.DATE })
    updatedOn: Date;
}
