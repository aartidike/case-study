const http = require("http");
//const app = require("./app");
const express=require('express');

require('./routes/customerroutes');
//const loans=require('./loans')
const bodyParser = require('body-parser');
// create express app
const app = express();

const server = http.createServer(app);
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

// parse application/json
app.use(bodyParser.json())
//apps.use('/api/loan',loans);

const { API_PORT } = process.env;
const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
