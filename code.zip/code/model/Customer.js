const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
    name:String,
  username: { type: String, unique: true },
  password: { type: String },
  address:String,
  state:String,
  country:String,
	email:String,
	pan:String,
	contact:String,
	dob:String,
  account_type:String,
  token: { type: String },
});

module.exports = mongoose.model("customer", customerSchema);
