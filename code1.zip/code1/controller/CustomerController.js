require("dotenv").config();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Customer = require("../model/Customer.js");

const auth = require("../middleware/auth.js");

const app = express();
app.use(express.json({ limit: "50mb" }));

exports.create=async (req, res) => {
    try {
      // Get user input
     console.log("inside api");

      const { name,username, password, address,state,country,email,pan,contact,dob,account_type} = req.body;
  
      // Validate user input
      if (!(name && username && password)) {
        res.status(400).send("name,username and password is required");
      }
  
      // check if user already exist
      // Validate if user exist in our database
      const oldCustomer = await Customer.findOne({ username });
  
      if (oldCustomer) {
        return res.status(409).send("customer Already Exist. Please Login");
      }
  
      //Encrypt user password
      encryptedPassword = await bcrypt.hash(password, 10);
  
      // Create user in our database
      const cus = await Customer.create({
        name,
        username,
         password:encryptedPassword, 
         address,
         state,
         country,
         email,
         pan,
         contact,
         dob,
         account_type
      });
  
      // Create token
      /*const token = jwt.sign(
        { user_id: cus._id, username },
        process.env.TOKEN_KEY,
        {
          expiresIn: "2h",
        }
      );
      // save user token
      cus.token = token;
  */
      // return new user
      res.status(201).json(cus);
    } catch (err) {
      console.log(err);
    }
}
  
  //Login
  exports.findOne= async (req, res) => {
    try {
      // Get user input
      const { username, password } = req.body;
  
      // Validate user input
      if (!(username && password)) {
        res.status(400).send("All input is required");
      }
      // Validate if user exist in our database
      const customer = await Customer.findOne({ username });
  
      if (customer && (await bcrypt.compare(password, customer.password))) {
        // Create token
        const token = jwt.sign(
          { user_id: customer._id, username },
          process.env.TOKEN_KEY,
          {
            expiresIn: "2h",
          }
        );
  
        // save user token
        customer.token = token;
  
        // user
        res.status(200).json(customer);
      }
      res.status(400).send("Invalid Credentials");
    } catch (err) {
      console.log(err);
    }
  }
  
  
  
  
