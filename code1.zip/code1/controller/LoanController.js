require("dotenv").config();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Loan = require("../model/Loans.js");
require('../controller/CustomerController')
const auth = require("../middleware/auth.js");

const app = express();

//getloan
exports.findById=async(req,res) => {
  try{
       Loan.findById({_id:req.params.id})
           .then((response) => {
           res.json({
             response,
           });
         })
       }
         catch(error){
           console.log(error)
         } 
  }
  
  //apply for loans
   exports.create=async (req,res) => {
  
  try{
       const loan = await Loan.create({
      username:req.body.username,
        loanType:req.body.loanType,
      loanAmount: req.body.loanAmount,
       date:req.body.date,
       rateOfInterest:req.body.rateOfInterest,
       durationOfLoan:req.body.durationOfLoan
      });
       
       res.status(200).send(loan);
     }catch(error){
       console.log(error)
     }
  }



  // exports.create=async(req,res)=>{
  
  //   const {loanType,loanAmount,date,rateOfInterest,durationOfLoan} = req.body;
  //   //encryptedPassword = await bcrypt.hash(password, 10);
  //   const loanuser = {
  //     //name:name,
  //     //username:username,
  //      //password:encryptedPassword, 
  //      loanType:loanType,
  //      loanAmount:loanAmount,
  //      date:date,
  //      rateOfInterest:rateOfInterest,
  //      durationOfLoan:durationOfLoan
  // };
  // Loan.create({_id:req.params.id},loanuser).then(function(employee){Loan.findOne({_id:req.params.id}).then(function(employee){
  //   res.send(employee);
  // })})
  // res.status(200).json(loanuser);
  // };
  
  
  
  
