require("dotenv").config();
require("./config/database").connect();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Loan = require("./model/Loans");
const auth = require("./middleware/auth");

const app = express();

app.get('/getloan/:id',auth,async(req,res) => {
    
    try{
       Loan.findById({_id:req.params.id})
           .then((response) => {
           res.json({
             response,
           });
         })
       }
         catch(error){
           console.log(error)
         } 
  });
  
  //apply for loans
  app.post('/applyLoan',auth,async (req,res) => {
  
  try{
       const loan = await Loan.create({
      username:req.body.username,
        loanType:req.body.loanType,
       loanAmount: req.body.loanAmount,
        date:req.body.date,
        rateOfInterest:req.body.rateOfInterest,
        durationOfLoan:req.body.durationOfLoan
       });
       
      res.status(200).send(loan);
    }catch(error){
       console.log(error)
     }
  });
  
  
  // This should be the last route else any after it won't work
  app.use("*", (req, res) => {
    res.status(404).json({
      success: "false",
      message: "Page not found",
      error: {
        statusCode: 404,
        message: "You reached a route that is not defined on this server",
      },
    });
  });
  
  
  module.exports = app;