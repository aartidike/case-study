const Joi = require('joi');
const mongoose = require('mongoose'); 
 
const loanSchema = new mongoose.Schema({
   
    username:{
        type:String,
        required:true
    },
    loanType: {
        type:String,
        required:true
    },
 
    loanAmount: {
        type:Number,
        required:true,
        minLength:5,
        maxLength:8
    },
    
    date: {
        type:String,
        required:true
    },
    
    rateOfInterest: {
        type:Number,
        required:true
    },
 
    durationOfLoan: {
        type:Number,
        required:true
    },
   
   
});

 module.exports = mongoose.model("Loans", loanSchema);