const auth=require('../middleware/auth');
module.exports = (app) => {
    const cus = require('../controller/CustomerController');
    const loan = require('../controller/LoanController');
    // Create a new Note
    app.post('/applyloan/:id',auth,loan.create);
    app.get('/getloan',loan.findById);
    app.post('/register', cus.create);
    
    // Retrieve all Notes
    app.get('/cus', cus.findAll);

    // Retrieve a single Note with noteId
    app.post('/login', cus.findOne);

    //Update a Note with noteId
    app.put('/update/:id', auth,cus.findOneAndUpdate);

    // Delete a Note with noteId
    //app.delete('/notes/:noteId', cus.delete);
}