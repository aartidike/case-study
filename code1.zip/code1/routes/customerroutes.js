module.exports = (app) => {
    const cus = require('../controller/CustomerController');

    // Create a new Note
    app.post('/register', cus.create);

    // Retrieve all Notes
    //app.get('/cus', cus.findAll);

    // Retrieve a single Note with noteId
    app.post('/login', cus.findOne);

     //Update a Note with noteId
    //app.put('/cus/:id', cus.update);

    // Delete a Note with noteId
    //app.delete('/notes/:noteId', cus.delete);
}