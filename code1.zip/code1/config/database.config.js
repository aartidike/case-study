module.exports = {
  url: 'mongodb+srv://nitesh:demo@cluster0.fdveb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}
