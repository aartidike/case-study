const express = require('express');
const bodyParser = require('body-parser');

// create express app
const app = express();

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

// parse application/json
app.use(bodyParser.json())

// Configuring the database

const dbConfig = require('./config/database.config.js');
 const mongoose = require('mongoose');

module.exports = {
    Loans: require("../code1/model/Loans"),
    Customer: require("../code1/model/Customer")
  };
// var Schema = mongoose.Schema;

// var customersSchema = new Schema({
//     username: String
// });

// module.exports = mongoose.model('Customer', customersSchema);
//var mongoose = require('mongoose');
//var Schema = mongoose.Schema;

// var loansSchema = new Schema({
//     username: String,
//     customers:[
//       {type: Schema.Types.ObjectId, ref: 'customers'}
//     ]
// });

// module.exports = mongoose.model('Loans', loansSchema);
mongoose.Promise = global.Promise;

// Connecting to the database
mongoose.connect(dbConfig.url, {
	useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

// define a simple route

app.get('/', (req, res) => {
    res.json({"message": "Welcome to EasyNotes application. Take notes quickly. Organize and keep track of all your notes."});
});

require('./routes/allroutes')(app);


app.get("/loan", function(req,res) {
    db.Loan.find({})
    .then(function(dbLoans) {
      res.json(dbLoans);
    })
    .catch(function(err) {
      res.json(err);
    })
  });
  app.get("/customer", function(req,res) {
    db.Customer.find({})
    .then(function(dbCustomer) {
      res.json(dbCustomer);
    })
    .catch(function(err) {
      res.json(err);
    })
  });
  app.post("/loans", function(req, res) {
    db.Loan.create(req.body)
      .then(function(dbloans) {
        // If we were able to successfully create a Product, send it back to the client
        res.json(dbloans);
      })
      .catch(function(err) {
        // If an error occurred, send it to the client
        res.json(err);
      });
  });











// listen for requests
app.listen(4000, () => {
    console.log("Server is listening on port 4000");
});

