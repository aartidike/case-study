/*require("dotenv").config();
require("./config/database").connect();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Customer = require("./controller/CustomerController");
const Loan = require("./controller/LoanController");
const auth = require("./middleware/auth");

const app = express();

app.use(express.json({ limit9: "50mb" }));

app.post("/register", async (req, res) => {
  try {
    // Get user input
    const { name,username, password, address,state,country,email,pan,contact,dob,account_type} = req.body;

    // Validate user input
    if (!(name && username && password)) {
      res.status(400).send("name,username and password is required");
    }

    // check if user already exist
    // Validate if user exist in our database
    const oldCustomer = await Customer.findOne({ username });

    if (oldCustomer) {
      return res.status(409).send("customer Already Exist. Please Login");
    }

    //Encrypt user password
    encryptedPassword = await bcrypt.hash(password, 10);

    // Create user in our database
    const cus = await Customer.create({
      name,
      username,
       password:encryptedPassword, 
       address,
       state,
       country,
       email,
       pan,
       contact,
       dob,
       account_type
    });

    // Create token
    const token = jwt.sign(
      { user_id: cus._id, username },
      process.env.TOKEN_KEY,
      {
        expiresIn: "2h",
      }
    );
    // save user token
    cus.token = token;

    // return new user
    
    res.status(201).json(cus);
  } catch (err) {
    console.log(err);
  }
});

//Login
app.post("/login", async (req, res) => {
  try {
    // Get user input
    const { username, password } = req.body;

    // Validate user input
    if (!(username && password)) {
      res.status(400).send("All input is required");
    }
    // Validate if user exist in our database
    const customer = await Customer.findOne({ username });

    if (customer && (await bcrypt.compare(password, customer.password))) {
      // Create token
      const token = jwt.sign(
        { user_id: customer._id, username },
        process.env.TOKEN_KEY,
        {
          expiresIn: "2h",
        }
      );

      // save user token
      customer.token = token;

      // user
      res.status(200).json(customer);
    }
    res.status(400).send("Invalid Credentials");
  } catch (err) {
    console.log(err);
  }
});


app.get("/welcome", auth, (req, res) => {
  res.status(200).send("Welcome ....Login successful!!! ");
});

//Update customers details
app.put("/update_customer/:id",async(req,res)=>{
  
  const { name,username, password, address,state,country,email,pan,contact,dob} = req.body;
  encryptedPassword = await bcrypt.hash(password, 10);
  const user = {
    name:name,
    username:username,
     password:encryptedPassword, 
     address:address,
     state:state,
     country:country,
     email:email,
     pan:pan,
     contact:contact,
     dob:dob
};
Customer.findOneAndUpdate({_id:req.params.id},user).then(function(employee){Customer.findOne({_id:req.params.id}).then(function(employee){
  res.send(employee);
})})
res.status(200).json(user);
});

app.post("/logout", auth,async (req, res) => {
  try {
    // Get user input
    const { username, password } = req.body;

    // Validate user input
    if (!(username && password)) {
      res.status(400).send("All input is required");
    }
    // Validate if user exist in our database
    const user = await Customer.findOne({ username });

    if (user && (await bcrypt.compare(password, user.password))) {
      // Create token
      const token = jwt.sign(
        { user_id: user._id, username },
        process.env.TOKEN_KEY,
        {
          expiresIn: "1ms",
        }
      );

      // save user token
      user.token = token;

      // user
      res.status(200).send("logout successful");
    }
    res.status(400).send("Invalid Credentials");
  } catch (err) {
    console.log(err);
  }

  
});

//...........................Loans API........................

//view loans
app.get('/getloan/:id',auth,async(req,res) => {
    
  try{
     Loan.findById({_id:req.params.id})
         .then((response) => {
         res.json({
           response,
         });
       })
     }
       catch(error){
         console.log(error)
       } 
});

//apply for loans
app.post('/applyLoan',auth,async (req,res) => {

try{
     const loan = await Loan.create({
    username:req.body.username,
      loanType:req.body.loanType,
     loanAmount: req.body.loanAmount,
      date:req.body.date,
      rateOfInterest:req.body.rateOfInterest,
      durationOfLoan:req.body.durationOfLoan
     });
     
    res.status(200).send(loan);
  }catch(error){
     console.log(error)
   }
});


// This should be the last route else any after it won't work
app.use("*", (req, res) => {
  res.status(404).json({
    success: "false",
    message: "Page not found",
    error: {
      statusCode: 404,
      message: "You reached a route that is not defined on this server",
    },
  });
});


module.exports = app;

*/
var db = require("./model");