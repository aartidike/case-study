require("dotenv").config();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Loan = require("../model/Loans.js");
const Customer=require("../model/Customer.js");
const auth = require("../middleware/auth.js");
//const { Customer } = require("../index.js");

const app = express();

//get all loans
exports.findAll= async (req,res)=> {
  Loan.find({})
  .then(function(dbProducts) {
    res.json(dbProducts);
  })
  .catch(function(err) {
    res.json(err);
  })
};









//getloan
exports.findById=async(req,res) => {
  try{
       Loan.findById({_id:req.params._id})
           .then((response) => {
           res.json({
             response,
           });
         })
       }
         catch(error){
           console.log(error)
         } 
  }
  
  exports.findOneAndUpdate= async(req, res)=> {
    // Create a new note and pass the req.body to the entry
    Customer.create(req.body)
      .then(function(dbReview) {
        
        // Since our mongoose query returns a promise, we can chain another `.then` which receives the result of the query
        return Loan.findOneAndUpdate({ _id: req.params.id }, { username: dbReview.username }, { new: true });
      })
      .then(function(dbProduct) {
        // If we were able to successfully update a Product, send it back to the client
        res.json(dbProduct);
      })
      .catch(function(err) {
        // If an error occurred, send it to the client
        res.json(err);
      });
  };

  //apply for loans
   exports.create=async (req,res) => {
      data=""
     
     data=Customer.findById({_id:req.params._id})
      
 console.log("data",data);
  
  try{
       const loan = await Loan.create({
      _id:req.params._id,
       username:data,
        loanType:req.body.loanType,
      loanAmount: req.body.loanAmount,
       date:req.body.date,
       rateOfInterest:req.body.rateOfInterest,
       durationOfLoan:req.body.durationOfLoan
      });
       
       res.status(200).send(loan);
     }catch(error){
       console.log(error)
     }
  
    }


  // exports.create=async(req,res)=>{
  
  //   const {loanType,loanAmount,date,rateOfInterest,durationOfLoan} = req.body;
  //   //encryptedPassword = await bcrypt.hash(password, 10);
  //   const loanuser = {
  //     //name:name,
  //     //username:username,
  //      //password:encryptedPassword, 
  //      loanType:loanType,
  //      loanAmount:loanAmount,
  //      date:date,
  //      rateOfInterest:rateOfInterest,
  //      durationOfLoan:durationOfLoan
  // };
  // Loan.create({_id:req.params.id},loanuser).then(function(employee){Loan.findOne({_id:req.params.id}).then(function(employee){
  //   res.send(employee);
  // })})
  // res.status(200).json(loanuser);
  // };
 
    
  
  
  
