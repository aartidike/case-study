var MongoClient = require('mongodb').MongoClient;
module.exports = {
  url: 'mongodb+srv://aarti:demo@cluster0.vg0qw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}

// MongoClient.connect(url, function(err, db) {
//   if (err) throw err;
//   var dbo = db.db("mydb");
//   dbo.collection('loans').aggregate([
//     { $lookup:
//        {
//          from: 'customers',
//          localField: 'username',
//          foreignField: '_username',
//          as: 'loans'
//        }
//      }
//     ]).toArray(function(err, res) {
//     if (err) throw err;
//     console.log(JSON.stringify(res));
//     db.close();
//   });
// });