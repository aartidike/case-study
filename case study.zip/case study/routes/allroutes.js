const auth=require('../middleware/auth');
module.exports = (app) => {
    const cus = require('../controller/CustomerController');
    const loan = require('../controller/LoanController');
    // Create a new Note
    app.post('/applyloan/:_id',loan.create);
    app.get('/getloan/:_id',loan.findById);
    app.post('/register', cus.create);
    //app.get('/getcus/:_id',cus.findById);
    app.post('/loan/:id',loan.findOneAndUpdate);
    app.get("/allLoans",loan.findAll);
    // Retrieve all Notes
    app.get('/allcustomers', cus.findAll);
    
    // Retrieve a single Note with noteId
    app.post('/login', cus.findOne);

    //Update a Note with noteId
    app.put('/update/:username',cus.findOneAndUpdate);
  
    // Delete a Note with noteId
    //app.delete('/notes/:noteId', cus.delete);
}