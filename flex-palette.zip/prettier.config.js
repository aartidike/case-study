// eslint-disable-next-line import/no-extraneous-dependencies
module.exports = require("@iff-devkit/eslint-config-rules/prettier.config");
