/* eslint-disable no-underscore-dangle */
import { Dialect } from "sequelize";
import { SequelizeModuleOptions } from "@nestjs/sequelize";
import * as models from "../models";
import { ConfigService } from "../modules/config/config.service";

/**
 * The function to create database providers to inject
 *
 * @export
 * @param {string} connection
 * @param {any[]} models
 * @returns {Provider[]}
 */
export function createGraDataBaseProviders(config: ConfigService): SequelizeModuleOptions {
    const databaseConnection = config.getConfig().DBConnections.appDBConnection;
    const connection: SequelizeModuleOptions = {
        dialect: databaseConnection.type as Dialect,
        database: databaseConnection.database,
        replication: {
            read: [
                {
                    host: databaseConnection.host,
                    username: databaseConnection.username,
                    password: databaseConnection.password,
                },
            ],
            write: {
                host: databaseConnection.host,
                username: databaseConnection.username,
                password: databaseConnection.password,
            },
        },
        // eslint-disable-next-line no-console
        logging: databaseConnection.logging ? console.log : false,
        dialectOptions: {
            requestTimeout: 1800000,
        },
    };
    connection.models = Object.values(models);
    return connection;
}
