import { HttpException, HttpStatus, Injectable, Logger } from "@nestjs/common";
import { Sequelize } from "sequelize-typescript";
import { ConfigService } from "./modules/config/config.service";

/**
 * Class Application Service
 *
 * @export
 * @class ApplicationService
 */
@Injectable()
export class AppService {
    /**
     *Creates an instance of ApplicationService.
     * @param {typeof Application} applicationModel
     * @param {MDRsService} mdrsService
     * @memberof ApplicationService
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly logger: Logger, private readonly configService: ConfigService, private sequelize: Sequelize) {}

    /**
     * To get the app details
     *
     * @returns {{ name; description; version; environment }}
     * @memberof AppService
     */
    public getApp(): { name; description; version; environment } {
        return this.configService.getApp();
    }

    /**
     * To get the application info
     *
     * @returns {{ name; version; database; databaseServer; MdrUser }}
     * @memberof AppService
     */
    public getAppInfo(): { name; version; database; databaseServer; MdrUser } {
        const app = this.configService.getApp();
        const databaseConfig = this.configService.getDatabase("appDBConnection");
        return {
            name: app.name,
            version: app.version,
            database: databaseConfig.database,
            databaseServer: databaseConfig.host,
            MdrUser: this.configService.getMdr().user.url,
        };
    }

    /**
     * To log the web logs
     *
     * @param {*} body
     * @param {*} logParameters
     * @memberof AppService
     */
    public logs(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
        body: any,
        logParameters: {
            applicationURL: string;
            sourceURL: string;
            targetURL: string;
            timestamp: Date;
        },
    ): void {
        const log = {
            level: "Error",
            errorMessage: body.additional[0].errorMessage,
            stackTrace: body.additional[0].stackTrace ? body.additional[0].stackTrace : body.additional[0].internalError,
            severity: body.additional[0].severity,
            userId: body.additional[0].userId,
            timestamp: body.timestamp,
            statusCode: body.additional[0].statusCode,
            statusCodeDescription: body.additional[0].statusCodeDescription,
            identification: "WEB",
            environment: this.configService.getApp().environment,
        };
        const logObject = { ...logParameters, ...log };
        this.logger.log(logObject, body.fileName);
    }

    /**
     * To Check the Database connection
     *
     * @returns {Promise<string>}
     * @memberof AppService
     */
    public async health(): Promise<unknown> {
        const databaseConfig = this.configService.getDatabase("appDBConnection");
        try {
            await this.sequelize.authenticate();
            return { [databaseConfig.database]: "ok" };
        } catch {
            throw new HttpException(`Unable to establish connection with ${databaseConfig.database}`, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
