/**
 * Mock testing varible of application
 */
export const APPLICATION_MOCK_DATA = {
    logsFormat: {
        message: "Authentication Failed",
        additional: [
            {
                applicationURL: "http://localhost:20200/",
                userId: "anonymous",
                severity: "ERROR",
                errorMessage: "Http failure response for http://localhost:20200/app-api/users/login: 500 Internal Server Error",
                statusCode: 500,
                statusCodeDescription: "Internal Server Error",
                url: "http://localhost:20200/app-api/users/login",
                internalError: "Cannot read property 'preferred_username' of null",
            },
        ],
        timestamp: "2020-05-29T12:31:00.333Z",
        fileName: "main.js",
        lineNumber: "1140",
    },
    logsAlternateFormat: {
        message: "App init error",
        additional: [
            {
                applicationURL: "http://localhost:20200/home",
                userId: "Anonymous",
                severity: "ERROR",
                errorMessage: "App init error",
                stackTrace: "Error: App init error",
            },
        ],
        level: 5,
        timestamp: "2020-05-29T09:18:28.034Z",
        fileName: "main.js",
        lineNumber: "780",
    },
};
