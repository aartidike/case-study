import { Controller, Get, HttpStatus, UseInterceptors, HttpCode, Post, Body } from "@nestjs/common";
import { ApiTags, ApiExcludeEndpoint, ApiOperation, ApiResponse, ApiBody } from "@nestjs/swagger";
import { RedirectInterceptor } from "./shared/interceptors/redirect.interceptor";
import { defaultSwaggerDecorators } from "./shared/decorators/swagger.decorator";
import { logFormat } from "./shared/decorators/log-format.decorator";
import { AppService } from "./app.service";

/**
 * The application controller is the root controller for the application
 *
 * @export
 * @class AppController
 * @extends {ConfigService}
 */
@defaultSwaggerDecorators()
@ApiTags("info")
@Controller("/")
export class AppController {
    // eslint-disable-next-line no-empty-function
    constructor(private readonly appService: AppService) {}

    /**
     * To get the Application
     *
     * @returns
     * @memberof AppController
     */
    @Get("/")
    @ApiOperation({ summary: "Get the application details" })
    @ApiResponse({ status: HttpStatus.OK, description: "Get the application details" })
    // eslint-disable-next-line @typescript-eslint/ban-types
    public GetApplication(): {} {
        return this.appService.getApp();
    }

    /**
     * To get the information about the application
     *
     * @returns {object}
     * @memberof AppController
     */
    @Get("info")
    @ApiOperation({ summary: "Get the configuration details" })
    @ApiResponse({ status: HttpStatus.OK, description: "Get the configuration details" })
    public GetAppInfo(): { name; version; database; databaseServer; MdrUser } {
        return this.appService.getAppInfo();
    }

    /**
     * To check the health of the application
     *
     * @public
     * @returns
     * @memberof AppController
     */
    @Get("ping")
    @ApiOperation({ summary: "To check if the application is live" })
    @ApiResponse({ status: HttpStatus.OK, description: "To check if the application is live" })
    // eslint-disable-next-line class-methods-use-this
    public Ping(): string {
        return "pong";
    }

    /**
     * To check the health of the application
     *
     * @static
     * @returns
     * @memberof AppController
     */
    @Get("/readme")
    @ApiExcludeEndpoint()
    @UseInterceptors(new RedirectInterceptor("http://127.0.0.1:8080"))
    // eslint-disable-next-line @typescript-eslint/no-empty-function, class-methods-use-this, no-empty-function
    Readme(): void {}

    /**
     * To return the favicon
     *
     * @static
     * @returns
     * @memberof AppController
     */
    @Get("/favicon.ico")
    @HttpCode(HttpStatus.NO_CONTENT)
    @ApiExcludeEndpoint()
    // eslint-disable-next-line @typescript-eslint/no-empty-function, class-methods-use-this, no-empty-function
    FavIcon(): void {}

    /**
     * Log the errors recevied via API
     *
     * @param {*} body
     * @returns {void}
     * @memberof AppController
     */
    @Post("logs")
    @ApiOperation({ summary: "To add the Logs" })
    @ApiResponse({ status: HttpStatus.OK, description: "To add the Logs" })
    @ApiBody({ description: "Request Body", type: "{error:{}, context: 'context'}" })
    public Logs(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
        @Body() body: any,
        @logFormat()
        logParameters: {
            applicationURL: string;
            sourceURL: string;
            targetURL: string;
            timestamp: Date;
        },
    ): void {
        this.appService.logs(body, logParameters);
    }

    @Get("/health")
    @ApiOperation({ summary: "To check if the database is live" })
    @ApiResponse({ status: HttpStatus.OK, description: "To check if the database is live" })
    // eslint-disable-next-line class-methods-use-this
    public health(): Promise<unknown> {
        return this.appService.health();
    }
}
