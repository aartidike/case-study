// eslint-disable-next-line no-shadow
export enum Environment {
    local = "local",
    development = "dev",
    qas = "qas",
    production = "prod",
    testing = "test",
}
