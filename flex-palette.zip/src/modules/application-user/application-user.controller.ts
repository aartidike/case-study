/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { Controller, Get, Post, Put, Body, Param, Header, HttpStatus, Req, Res } from "@nestjs/common";
import { ApiResponse, ApiTags, ApiParam, ApiBody, ApiOperation } from "@nestjs/swagger";
import { ApplicationUserService } from "./application-user.service";
import { ApplicationUserRequestDto } from "../../dtos/application-user.request.dto";
import { ApplicationUserResponseDto } from "../../dtos/application-user.response.dto";
import { defaultSwaggerDecorators } from "../../shared/decorators/swagger.decorator";
import { MDRUsersService } from "../mdr/mdr-user.service";

/**
 * Class ApplicationUserController
 *
 * @export
 * @class ApplicationUserController
 */
@ApiTags("users")
@defaultSwaggerDecorators()
@Controller("users")
export class ApplicationUserController {
    /**
     *Creates an instance of ApplicationUserController.
     * @param {ApplicationUserService} applicationUserService
     * @param {MDRService} mdrUsersService
     * @memberof ApplicationUserController
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly applicationUserService: ApplicationUserService, private readonly mdrUsersService: MDRUsersService) {}

    /**
     * To Get the user details based on authorization userId
     *
     * @param {*} Param
     * @returns
     * @memberof UsersController
     */
    @Get("me")
    @ApiResponse({ status: HttpStatus.OK, description: "User data found for the current user" })
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async getCurrentUser(@Req() request): Promise<any> {
        return this.applicationUserService.getCurrentUser(request.headers.authorization);
    }

    /**
     * To Get the applicationUser details
     *
     * @returns {Promise<{ ApplicationUsers: ApplicationUserResponseDto[] }>}
     * @memberof ApplicationUserController
     */
    @Get()
    @ApiOperation({ summary: "Return all the ApplicationUser" })
    @ApiResponse({ status: HttpStatus.OK, description: "The request has succeeded.", type: ApplicationUserResponseDto })
    async GetAll(): Promise<{ applicationUsers: ApplicationUserResponseDto[] }> {
        const result = await this.applicationUserService.findAll();
        return { applicationUsers: result };
    }

    /**
     * To Get the applicationUser details based on ApplicationUser Id
     *
     * @param {*} Param
     * @returns
     * @memberof ApplicationUserController
     */
    @Get(":id")
    @ApiOperation({ summary: "Return ApplicationUser" })
    @ApiResponse({ status: HttpStatus.OK, description: "The request succeeded.", type: ApplicationUserResponseDto })
    @ApiParam({ name: "id", description: "Id of the ApplicationUser to get the details" })
    async GetById(@Param("id") applicationUserId): Promise<ApplicationUserResponseDto | null> {
        const result = await this.applicationUserService.findOne(applicationUserId);
        return result;
    }

    /**
     * To Create the applicationUser details
     *
     * @param ApplicationUserDto
     * @param {*} request
     * @returns {Promise<void>}
     * @memberof ApplicationUserController
     */
    @Post()
    @Header("content-type", "application/json")
    @ApiOperation({ summary: "Create ApplicationUser" })
    @ApiResponse({
        status: HttpStatus.CREATED,
        description: "The ApplicationUser has been successfully created",
        type: ApplicationUserResponseDto,
    })
    @ApiBody({ description: "Request Body", type: ApplicationUserRequestDto })
    async Create(@Body() applicationUserDto: ApplicationUserRequestDto, @Req() request): Promise<void> {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const userDetails: any = await this.mdrUsersService.getCurrentUser(request.headers.authorization);
        Object.assign(applicationUserDto, { createdBy: userDetails.globalUserId });
        await this.applicationUserService.create(applicationUserDto);
    }

    /**
     * To update the applicationUser details by ApplicationUser Id
     *
     * @param {*} ApplicationUserId
     * @param ApplicationUserRequestDto
     * @param {*} request
     * @returns {Promise<void>}
     * @memberof ApplicationUserController
     */
    @Put(":id")
    @Header("content-type", "application/json")
    @ApiOperation({ summary: "Update ApplicationUser" })
    @ApiResponse({ status: HttpStatus.OK, description: "The request has been successfully updated.", type: ApplicationUserResponseDto })
    @ApiBody({ description: "Request Body", type: ApplicationUserRequestDto })
    @ApiParam({ name: "id", description: "Id of the ApplicationUser to update" })
    async Update(@Param("id") applicationUserId, @Body() applicationUserDto: ApplicationUserRequestDto, @Req() request): Promise<void> {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const userDetails: any = await this.mdrUsersService.getCurrentUser(request.headers.authorization);
        Object.assign(applicationUserDto, { updatedBy: userDetails.globalUserId });
        await this.applicationUserService.update(applicationUserId, applicationUserDto);
    }

    /**
     * To get the user details based on the user ID
     *
     * @param {*} Param
     * @returns
     * @memberof UsersController
     */
    @Post("/login")
    @ApiResponse({ status: HttpStatus.OK, description: "User data found" })
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async login(@Req() request): Promise<any> {
        return this.applicationUserService.getCurrentUser(request.headers.authorization);
    }

    /**
     * To Get the User Photo
     *
     * @param {*} Param
     * @returns
     * @memberof Controller
     */
    @Get("/:userId/photo")
    @Header("Content-Type", "image/png")
    @ApiResponse({ status: HttpStatus.OK, description: "Get mdrUsers photo" })
    @ApiResponse({ status: HttpStatus.NOT_FOUND, description: "Not found" })
    @ApiParam({ name: "userId" })
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async getUserPhoto(@Param() parameter, @Res() response): Promise<any> {
        const result = await this.mdrUsersService.getUserPhoto(parameter.userId);
        result.data.pipe(response);
        return new Promise((resolve, reject) => {
            response.on("finish", resolve);
            response.on("error", reject);
        });
    }
}
