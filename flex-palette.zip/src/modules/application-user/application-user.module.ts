import { Module, HttpModule } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { ApplicationUserController } from "./application-user.controller";
import { ApplicationUserService } from "./application-user.service";
import { ApplicationUser } from "../../models/application-user.model";
import { MDRUsersService } from "../mdr/mdr-user.service";

@Module({
    imports: [SequelizeModule.forFeature([ApplicationUser]), HttpModule],
    providers: [ApplicationUserService, MDRUsersService],
    controllers: [ApplicationUserController],
})
export class ApplicationUserModule {}
