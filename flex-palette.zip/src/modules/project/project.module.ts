import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { ProjectHeaderModel } from "../../models";
import { ProjectController } from "./project.controller";
import { ProjectService } from "./project.service";

@Module({
    imports: [SequelizeModule.forFeature([ProjectHeaderModel])],
    controllers: [ProjectController],
    providers: [ProjectService],
})
export class ProjectModule {}
