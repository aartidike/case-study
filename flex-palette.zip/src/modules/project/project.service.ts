import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { ProjectHeaderModel } from "../../models/project-header.model";

@Injectable()
export class ProjectService {
    constructor(@InjectModel(ProjectHeaderModel) private ProjectModel: typeof ProjectHeaderModel) {}

    public async getProject(): Promise<any> {
        return this.ProjectModel.findAll({ attributes: ["source", "endUse"], where: { projId: "0000007368" } });
    }
}
