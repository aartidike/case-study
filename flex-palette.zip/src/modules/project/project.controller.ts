import { Controller, Get, HttpStatus } from "@nestjs/common";
import { ApiOperation, ApiResponse } from "@nestjs/swagger";
import { ProjectService } from "./project.service";

@Controller("project")
export class ProjectController {
    constructor(private projectService: ProjectService) {
        // eslint-disable-next-line no-console
        console.log("Here");
    }

    @Get()
    @ApiOperation({ summary: "Returns Project information", description: "Get Project information by Project ID" })
    @ApiResponse({
        status: HttpStatus.OK,
        description: "Get Project Information",
    })
    async getProjectInfo(): Promise<any> {
        // eslint-disable-next-line no-console
        console.log("getting project Info");
        const data = await this.projectService.getProject();
        return data;
    }
}
