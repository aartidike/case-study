export interface OktaConfig {
    /**
     * The URL of the okta
     *
     * @type {string}
     * @memberof OktaConfig
     */
    url: string;

    /**
     * The client ID of the okta
     *
     * @type {string}
     * @memberof OktaConfig
     */
    clientId: string;

    /**
     * Array of URL to exclude
     *
     * @type {*}
     * @memberof OktaConfig
     */
    excludes: string[];

    /**
     * To disable the Authentication
     *
     * @type {boolean}
     * @memberof OktaConfig
     */
    isDisabled: boolean;

    /**
     * Default User when the Authentication is disabled
     *
     * @type {string}
     * @memberof OktaConfig
     */
    mockUserId: string;
}
