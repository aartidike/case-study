import { DBConnections } from "./database-connection";
import { MDR } from "./mdr";
import { OktaConfig } from "./okta-config";
import { RedisConfig } from "./redis";

export interface Config {
    /**
     * Port number of the application
     *
     * @type {number}
     * @memberof Config
     */
    Port: number;

    /**
     * Environment
     *
     * @type {string}
     * @memberof Config
     */
    Environment: string;

    /**
     * Environment
     *
     * @type {number}
     * @memberof Config
     */
    RequestTimeout: number;

    /**
     * The total DB connections of the application
     *
     * @type {DBConnections}
     * @memberof Config
     */
    DBConnections: DBConnections;

    /**
     * The MDR details
     *
     * @type {MDR}
     * @memberof Config
     */
    MDR: MDR;

    /**
     * Okta Configurations
     *
     * @type {OktaConfig}
     * @memberof Config
     */
    OktaConfig: OktaConfig;

    /**
     * Redis Configurations
     *
     * @type {OktaConfig}
     * @memberof Config
     */
    Redis: RedisConfig;
}
