import { Module, HttpModule } from "@nestjs/common";
import { MDRUsersService } from "./mdr-user.service";
import { ConfigModule } from "../config/config.module";

@Module({
    imports: [HttpModule, ConfigModule],
    controllers: [],
    providers: [MDRUsersService],
})
export class MDRModule {}
