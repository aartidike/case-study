/* eslint-disable max-lines-per-function */
import { HttpModule, CacheModule, HttpService } from "@nestjs/common";
import { Test } from "@nestjs/testing";
import { of, throwError } from "rxjs";
import { MDRUsersService } from "./mdr-user.service";
import { ConfigModule } from "../config/config.module";
import { MOCK_DATA } from "./mdr-user.mock.data";

describe("User Module", () => {
    let httpService: HttpService;
    let mdrUsersService: MDRUsersService;

    beforeEach(async () => {
        const moduleReference = await Test.createTestingModule({
            providers: [MDRUsersService],
            imports: [HttpModule, ConfigModule, CacheModule.register({})],
        }).compile();

        httpService = moduleReference.get<HttpService>(HttpService);
        mdrUsersService = moduleReference.get<MDRUsersService>(MDRUsersService);
    });

    describe("Get User Details By UserID", () => {
        it("Should return an array of users", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const response = await mdrUsersService.getUserDetailsByUserID(MOCK_DATA.userId);
            expect(response).toBe(MOCK_DATA.userData.data.users[0]);
        });

        it("Should throw Http Exception for No User found", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => throwError(MOCK_DATA.notFound));
            try {
                // eslint-disable-next-line unicorn/no-null
                await mdrUsersService.getUserDetailsByUserID(null);
            } catch (error) {
                expect(error).toEqual(MOCK_DATA.notFound);
            }
        });
    });

    describe("Get User Details By EmailID", () => {
        it("Should return an array of users", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userDataByEmail));
            const response = await mdrUsersService.getUserDetailsByEmail(MOCK_DATA.emailId);
            expect(response).toBe(MOCK_DATA.userDataByEmail.data);
        });

        it("Should throw Http Exception Provide Email Id(s)", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => {
                throw new Error("Provide Email Id(s)");
            });
            try {
                // eslint-disable-next-line unicorn/no-null
                await mdrUsersService.getUserDetailsByEmail(null);
            } catch (error) {
                expect(error.message).toEqual("Provide Email Id(s)");
            }
        });

        it("Should throw Http Exception no user found by email", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => throwError(MOCK_DATA.notFound));
            try {
                await mdrUsersService.getUserDetailsByEmail(MOCK_DATA.emailId);
            } catch (error) {
                expect(error).toEqual(MOCK_DATA.notFound);
            }
        });
    });

    describe("Get Current User Details By UserID", () => {
        it("Should return a default user", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            // eslint-disable-next-line unicorn/no-null
            const response = await mdrUsersService.getCurrentUser(null);
            expect(response).toBe(MOCK_DATA.userData.data.users[0]);
        });

        it("Should return an user", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const response = await mdrUsersService.getCurrentUser(MOCK_DATA.jwt);
            expect(response).toBe(MOCK_DATA.userData.data.users[0]);
        });

        it("Should return an user based on Bearer Token", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const response = await mdrUsersService.getCurrentUser(`Bearer ${MOCK_DATA.jwt}`);
            expect(response).toBe(MOCK_DATA.userData.data.users[0]);
        });
    });

    describe("Login with the token", () => {
        it("Should return an user object", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const response = await mdrUsersService.login(MOCK_DATA.jwt);
            expect(response).toBe(MOCK_DATA.userData.data.users[0]);
        });
    });

    describe("Get User By Ids", () => {
        it("Should return an array of users based on id", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const response = await mdrUsersService.getMultipleUserDetailsByUserIds(MOCK_DATA.userId);
            expect(response).toBe(MOCK_DATA.userData.data);
        });

        it("Should throw Http Exception Provide User Id(s)", async () => {
            try {
                // eslint-disable-next-line unicorn/no-null
                await mdrUsersService.getMultipleUserDetailsByUserIds(null);
            } catch (error) {
                expect(error.message).toEqual("Provide User Id(s)");
            }
        });
    });

    // describe("Get User Photo", () => {
    //     it("Should return photo of users based on id", async () => {
    //         const mock = new MockAdapter(axios);
    //         const data = { response: true };
    //         mock.onGet("https://ion-qas.iff.com/api/v1/users/GXR9790/photo?returnemptyimage=false").reply(HttpStatus.OK, data);
    //         const result = await mdrUsersService.getUserPhoto("GXR9790");
    //         expect(result.status).toEqual(HttpStatus.OK);
    //     });

    //     it("Should throw Http Exception Provide User Id(s)", async () => {
    //         try {
    //             // eslint-disable-next-line unicorn/no-null
    //             await mdrUsersService.getMultipleUserDetailsByUserIds(null);
    //         } catch (error) {
    //             expect(error.message).toEqual("Provide User Id(s)");
    //         }
    //     });
    // });
});
