import { NestFactory, NestApplication } from "@nestjs/core";
import { FileLoggerService } from "@iff/api-logger";
import { AppModule } from "./app.module";
import { WebApi } from "./webapi";
import { ConfigService } from "./modules/config/config.service";

/**
 * Module for the hot reload
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare const module: any;

/**
 * The bootstap function which runs the application
 *
 * @returns {Promise<void>}
 */
async function bootstrap(): Promise<void> {
    const app = await NestFactory.create<NestApplication>(AppModule, {
        logger: false,
    });
    const configService = app.get(ConfigService);
    app.useLogger(app.get(FileLoggerService));
    const api = new WebApi(app, configService);
    api.Listen();

    if (module.hot) {
        module.hot.accept();
        module.hot.dispose(() => app.close());
    }
}

bootstrap();
