/* eslint-disable max-lines-per-function */
import * as request from "supertest";
import { Test } from "@nestjs/testing";
import { INestApplication } from "@nestjs/common";
import { AppModule } from "./app.module";
import { helper } from "./shared/test/helper";
import { APPLICATION_MOCK_DATA } from "./app.mockdata";

describe("/", () => {
    let app: INestApplication;
    beforeAll(async () => {
        const module = await Test.createTestingModule({
            imports: [AppModule],
        }).compile();

        app = module.createNestApplication();
        await app.init();
    });

    /**
     * To Get the application details
     *
     * @param {*} Param
     * @returns
     * @memberof AppController
     */
    it("/GET get application details", async () => {
        const applicationDetails = await request(app.getHttpServer()).get("/");
        helper.validateSuccess(applicationDetails, {}, {});
    });

    /**
     * To Get the configuration details
     *
     * @param {*} Param
     * @returns
     * @memberof AppController
     */
    it("/GET Get the configuration details", async () => {
        const configDetails = await request(app.getHttpServer()).get("/info");
        helper.validateSuccess(configDetails, {}, {});
    });

    /**
     * Ping
     * @returns
     * @memberof AppController
     */
    it("/GET Ping", async () => {
        const response = await request(app.getHttpServer()).get("/ping");
        helper.validateSuccess(response, {}, {});
    });

    /**
     * Post logs
     * @returns
     * @memberof AppController
     */
    it("/POST logs", async () => {
        await request(app.getHttpServer()).post("/logs").send(APPLICATION_MOCK_DATA.logsFormat);
    });

    /**
     * Post logs
     * @returns
     * @memberof AppController
     */
    it("/POST logs alternate format", async () => {
        await request(app.getHttpServer()).post("/logs").send(APPLICATION_MOCK_DATA.logsAlternateFormat);
    });

    /**
     * readme
     * @returns
     * @memberof AppController
     */
    it("/GET Readme", async () => {
        const response = await request(app.getHttpServer()).get("/readme");
        helper.validateFound(response);
    });

    /**
     * Favicon
     * @returns
     * @memberof AppController
     */
    it("/GET Favicon", async () => {
        const response = await request(app.getHttpServer()).get("/favicon.ico");
        helper.validateNoContent(response);
    });
});
