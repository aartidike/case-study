import { Module, Global, NestModule, MiddlewareConsumer, HttpModule, RequestMethod } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { LoggerMiddleware, LoggerModule } from "@iff/api-logger";
import { AllExceptionsFilter } from "@iff/api-exception";
import { RedisModule } from "nestjs-redis";
import { AuthenticationModule, AuthenticationMiddleware } from "@iff/api-auth";
import { AppController } from "./app.controller";
import { ConfigModule } from "./modules/config/config.module";
import { ConfigService } from "./modules/config/config.service";
import { MDRModule } from "./modules/mdr/mdr.module";
// import * as models from "./models";
import { ApplicationUserModule } from "./modules/application-user/application-user.module";
import { AppService } from "./app.service";
// import { ProjectHeaderModel } from "./models";
import { ProjectModule } from "./modules/project/project.module";
import { createGraDataBaseProviders } from "./database/database.provider";

/**
 * The Root module of the application
 *
 * @export
 * @class AppModule
 * @implements {NestModule}
 */
@Global()
@Module({
    controllers: [AppController],
    providers: [AllExceptionsFilter, AppService],
    imports: [
        ConfigModule,
        HttpModule,
        ProjectModule,
        MDRModule,
        AuthenticationMiddleware,
        SequelizeModule.forRootAsync({
            inject: [ConfigService],
            useFactory: async (config: ConfigService) => createGraDataBaseProviders(config),
        }),
        // SequelizeModule.forRootAsync({
        //     inject: [ConfigService],
        //     useFactory: (config: ConfigService) => {
        //         const databaseConnection = config.getConfig().DBConnections.appDBConnection;
        //         const connection: SequelizeModuleOptions = {
        //             dialect: "postgres",
        //             database: databaseConnection.database,
        //             replication: {
        //                 read: [
        //                     {
        //                         host: databaseConnection.host,
        //                         username: databaseConnection.username,
        //                         password: databaseConnection.password,
        //                     },
        //                 ],
        //                 write: {
        //                     host: databaseConnection.host,
        //                     username: databaseConnection.username,
        //                     password: databaseConnection.password,
        //                 },
        //             },
        //             // eslint-disable-next-line no-console
        //             logging: databaseConnection.logging ? console.log : false,
        //         };
        //         connection.models = Object.values(ProjectHeaderModel);
        //         // eslint-disable-next-line no-console
        //         console.log("Models----->", models);
        //         return connection;
        //     },
        // }),
        LoggerModule.forRoot({
            useFactory: (config: ConfigService) => ({
                applicationName: config.getApp().name,
                environment: config.getApp().environment,
                logAll: true,
                addLogsToFile: true,
            }),
            inject: [ConfigService],
        }),
        AuthenticationModule.forRoot({
            inject: [ConfigService],
            useFactory: (config: ConfigService) => {
                const oktaConfig = config.getOktaConfig();
                return {
                    url: oktaConfig.url,
                    clientId: oktaConfig.clientId,
                    excludeRoutes: oktaConfig.excludes,
                    // Make sure not to disable authentication, disable only for testing purpose
                    isDisabled: oktaConfig.isDisabled,
                };
            },
        }),
        RedisModule.forRootAsync({
            inject: [ConfigService],
            useFactory: (configService: ConfigService) => configService.getRedis(),
        }),
        ApplicationUserModule,
    ],
    exports: [],
})
export class AppModule implements NestModule {
    // eslint-disable-next-line class-methods-use-this
    configure(consumer: MiddlewareConsumer): void {
        consumer.apply(LoggerMiddleware, AuthenticationMiddleware).forRoutes({ path: "*", method: RequestMethod.ALL });
    }
}
