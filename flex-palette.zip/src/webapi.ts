import { NestApplication } from "@nestjs/core";
import * as cookieParser from "cookie-parser";
import * as helmet from "helmet";
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
import { Logger, ValidationPipe } from "@nestjs/common";
import * as compression from "compression";
import { FileLoggerService } from "@iff/api-logger";
import { AllExceptionsFilter } from "@iff/api-exception";
import { ConfigService } from "./modules/config/config.service";
import { ResponseTimeInterceptor } from "./shared/interceptors/response-time.interceptor";
import { TimeoutInterceptor } from "./shared/interceptors/timeout.interceptor";
import { Environment } from "./enums";

/**
 * ConfigService to inject configurations
 *
 * @export
 * @class WebApi
 */
export class WebApi {
    /**
     * To set the application
     *
     * @private
     * @type {NestApplication}
     * @memberof WebApi
     */
    private app: NestApplication;

    /**
     * To set the Configurations
     *
     * @private
     * @type {ConfigService}
     * @memberof WebApi
     */
    private configService: ConfigService;

    /**
     * To Set the logger
     *
     * @private
     * @type {Logger}
     * @memberof WebApi
     */
    private logger: Logger;

    /**
     * Creates an instance of WebApi.
     * @param {NestApplication} application
     * @param {ConfigService} _configService
     * @memberof WebApi
     */
    constructor(application: NestApplication, _configService: ConfigService) {
        this.app = application;
        this.configService = _configService;
        this.logger = this.app.get(FileLoggerService);
        this.initialize();
    }

    /**
     * Establish connection to the server
     *
     * @memberof WebApi
     */
    public Listen(): void {
        const port = this.configService.getPort();
        this.app.listen(port);
        Logger.log(`Listening on port: ${port} in the ${this.configService.getApp().environment} environment`, "Bootstrap");
    }

    /**
     * To Initialize the configurations
     *
     * @private
     * @memberof WebApi
     */
    private initialize(): void {
        this.initializeSecurityConfigurations();
        this.initializeDocumentationConfigurations();
        this.initializeFiltersConfigurations();
        this.initializeInterceptorsConfigurations();
        this.initializeValidationConfigurations();
        this.initializeCompression();
    }

    /**
     * To Initialize the documentation related configurations
     *
     * @memberof WebApi
     */
    private initializeDocumentationConfigurations(): void {
        const app = this.configService.getApp();
        const options = new DocumentBuilder()
            .setTitle(app.name)
            .setDescription(app.description)
            .setVersion(app.version)
            .addBearerAuth()
            .build();
        if (app.environment !== Environment.production) {
            const document = SwaggerModule.createDocument(this.app, options);
            SwaggerModule.setup("docs", this.app, document);
        }
    }

    /**
     * To Initialize the Filters Configurations
     *
     * @memberof WebApi
     */
    private initializeFiltersConfigurations(): void {
        this.app.useGlobalFilters(new AllExceptionsFilter(this.logger));
    }

    /**
     * To Initialize the Interceptors Configurations
     *
     * @memberof WebApi
     */
    private initializeInterceptorsConfigurations(): void {
        this.app.useGlobalInterceptors(new ResponseTimeInterceptor(this.logger));
        this.app.useGlobalInterceptors(new TimeoutInterceptor(this.configService.getConfig().RequestTimeout));
    }

    /**
     * To Initialize the Security Configurations
     *
     * @memberof WebApi
     */
    private initializeSecurityConfigurations(): void {
        this.app.use(helmet());
        this.app.use(cookieParser());
    }

    /**
     * To Initialize the Validation Configurations
     *
     * @memberof WebApi
     */
    private initializeValidationConfigurations(): void {
        this.app.useGlobalPipes(new ValidationPipe({ transform: true }));
    }

    /**
     * The middleware to compress response bodies for all requests
     *
     * @private
     * @memberof WebApi
     */
    private initializeCompression(): void {
        this.app.use(compression());
    }
}
