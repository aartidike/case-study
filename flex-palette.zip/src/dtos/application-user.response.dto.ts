import { ApiProperty } from "@nestjs/swagger";

/**
 * Class ApplicationUserResponse Dto
 *
 * @export
 * @class ApplicationUserResponseDto
 */
export class ApplicationUserResponseDto {
    /**
     * userId
     *
     * @type {number}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: 1, description: "UserId of the User" })
    userId: number;

    /**
     * globalUserId
     *
     * @type {string}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "txc3690", description: "GlobalUserId of the User" })
    globalUserId: string;

    /**
     * isActive
     *
     * @type {number}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "1", description: "IsActive of the User" })
    isActive: number;

    /**
     * createdBy
     *
     * @type {string}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "axr5756", description: "CreatedBy of the User" })
    createdBy: string;

    /**
     * createdOn
     *
     * @type {Date}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "2017-05-13 07:59:38", description: "CreatedOn of the User" })
    createdOn: Date;

    /**
     * updatedBy
     *
     * @type {string}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "GXR9790", description: "UpdatedBy of the User" })
    updatedBy: string;

    /**
     * updatedOn
     *
     * @type {Date}
     * @memberof MDRUserResponseDto
     */
    @ApiProperty({ example: "2017-05-13 07:59:38", description: "UpdatedOn of the User" })
    updatedOn: Date;
}
