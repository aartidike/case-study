import { ApiProperty } from "@nestjs/swagger";
import { IsString, IsInt, IsUppercase } from "class-validator";

/**
 * Class ApplicationUserRequest Dto
 *
 * @export
 * @class ApplicationUserRequestDtoDto
 */
export class ApplicationUserRequestDto {
    /**
     * globalUserId
     *
     * @type {string}
     * @memberof MDRUserRequestDtoDto
     */
    @ApiProperty({ example: "GXR9790", description: "GlobalUserId of the User" })
    @IsString()
    @IsUppercase()
    globalUserId: string;

    /**
     * isActive
     *
     * @type {number}
     * @memberof MDRUserRequestDtoDto
     */
    @ApiProperty({ example: "1", description: "IsActive of the User" })
    @IsInt()
    isActive: number;
}
