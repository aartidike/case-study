/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { HttpStatus } from "@nestjs/common";

/**
 * The helper variable
 */
const helper = {
    validateSuccess: (response, data, properties) => {
        expect(response.status).toEqual(HttpStatus.OK);
        expect(data).toEqual(properties);
    },
    validateNoContent: (response) => {
        expect(response.status).toEqual(HttpStatus.NO_CONTENT);
    },
    validateFound: (response) => {
        expect(response.status).toEqual(HttpStatus.FOUND);
    },
    /* Can uncomment based on the need
    validateCreated: (response) => {
        expect(response.status).toEqual(HttpStatus.CREATED);
    },
    validateBadRequest: (response) => {
        expect(response.status).toEqual(HttpStatus.BAD_REQUEST);
    },
    validateUnauthrized: (response) => {
        expect(response.status).toEqual(HttpStatus.UNAUTHORIZED);
    },
    validateForbidden: (response) => {
        expect(response.status).toEqual(HttpStatus.FORBIDDEN);
    },
    validateNotFound: (response) => {
        expect(response.status).toEqual(HttpStatus.NOT_FOUND);
    },
    validateUnsupportedMediaType: (response) => {
        expect(response.status).toEqual(HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    },
    validateUnprocessableEntity: (response) => {
        expect(response.status).toEqual(HttpStatus.UNPROCESSABLE_ENTITY);
    },
    validateInternalServer: (response) => {
        expect(response.status).toEqual(HttpStatus.INTERNAL_SERVER_ERROR);
    },
    validateGatewayTimeout: (response) => {
        expect(response.status).toEqual(HttpStatus.GATEWAY_TIMEOUT);
    }, */
};

export { helper };
