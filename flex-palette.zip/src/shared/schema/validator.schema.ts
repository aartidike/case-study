import * as Joi from "@hapi/joi";

/**
 * The class to Validating schema
 *
 * @export
 * @class ValidatorSchema
 */
export class ValidatorSchema {
    /**
     * To get the Database connection details
     *
     * @returns
     * @memberof ValidatorSchema
     */
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public getDBConnections(): Joi.ObjectSchema<any> {
        return Joi.object().keys({
            host: Joi.string().required(),
            username: Joi.string().required(),
            password: Joi.string().required(),
            database: Joi.string().required(),
            type: Joi.string().required().valid("postgres", "mysql", "mssql").default("postgres"),
            logging: Joi.boolean().required().default(false),
        });
    }

    /**
     * To get the MDR details
     *
     * @returns
     * @memberof ValidatorSchema
     */
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public getMDR(): Joi.ObjectSchema<any> {
        return Joi.object()
            .keys({
                user: Joi.object()
                    .keys({
                        url: Joi.string().required(),
                    })
                    .required(),
            })
            .required();
    }

    /**
     * To get the Okta Configuration details
     *
     * @returns
     * @memberof ValidatorSchema
     */
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public getOktaConfig(): Joi.ObjectSchema<any> {
        return Joi.object()
            .keys({
                url: Joi.string().required(),
                clientId: Joi.string().required(),
                excludes: Joi.array().required(),
                isDisabled: Joi.boolean().required(),
                mockUserId: Joi.string(),
            })
            .required();
    }
}
