/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { Injectable } from "@nestjs/common";
import { RedisService } from "nestjs-redis";
import * as moment from "moment";

/**
 * CacheService
 *
 * @export
 * @class CacheService
 */
@Injectable()
export class CacheService {
    /**
     * Initiate redis client
     *
     * @private
     * @type {Redis}
     * @memberof CacheService
     */
    private redisClient: any;

    /**
     *Creates an instance of CacheService.
     * @param {RedisService} redisService
     * @memberof CacheService
     */
    constructor(private readonly redisService: RedisService) {
        this.redisClient = this.redisService.getClient();
    }

    /**
     * To get the Redis Key
     *
     * @param {string} key
     * @returns {Promise<any>}
     * @memberof CacheService
     */
    public async getByKey(key: string): Promise<any> {
        const result = await this.redisClient.get(key);
        return result;
    }

    /**
     * To get Multiple Redis Keys
     *
     * @param {string} key
     * @returns {Promise<any>}
     * @memberof CacheService
     */
    public async getByMultipleKeys(key: any): Promise<any> {
        const result = await this.redisClient.mget(key);
        return result;
    }

    /**
     * To set Redis Keys
     *
     * @param {({ key: string; value: string | object; ttl?: number })} { key, value, ttl }
     * @returns {Promise<any>}
     * @memberof CacheService
     */
    public async set(key: string, value: string | unknown, ttl?: number): Promise<any> {
        if (ttl) {
            this.redisClient.set(key, JSON.stringify(value), "EX", this.converToSeconds(ttl));
        }
        const result = await this.redisClient.set(key, JSON.stringify(value));
        return result;
    }

    /**
     * To delete redis keys
     *
     * @param {string} key
     * @returns {Promise<any>}
     * @memberof CacheService
     */
    public async deleteByKey(key: string): Promise<any> {
        const result = await this.redisClient.del(key);
        return result;
    }

    /**
     * To return time difference in seconds
     *
     * @private
     * @param {*} ttl
     * @returns {number}
     * @memberof RedisInterceptor
     */
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    private converToSeconds(ttl: any): number {
        const timeA = moment.utc(ttl, "H:mm:ss");
        const timeB = timeA.clone().startOf("day");
        return timeA.diff(timeB, "seconds");
    }
}
