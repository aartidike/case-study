import { createParamDecorator, ExecutionContext } from "@nestjs/common";

/**
 * The custom decorator to get the defined data for logging
 */
export const logFormat = createParamDecorator((_data: unknown, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest();
    const appURL = `${request.protocol}://${request.get("host")}`;
    const sourceURL = request.header("Referer") ? request.header("Referer") : "Unknown caller";
    return {
        applicationURL: appURL,
        sourceURL: `${sourceURL}`,
        targetURL: `${appURL}${request.originalUrl}`,
        timestamp: new Date().toISOString(),
    };
});
