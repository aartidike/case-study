/* eslint-disable max-len */
import { applyDecorators, HttpStatus } from "@nestjs/common";
import { ApiBearerAuth, ApiResponse } from "@nestjs/swagger";

/**
 * The function to set the reusable swagger decorators
 *
 * @returns {Function}
 */
// eslint-disable-next-line @typescript-eslint/ban-types
export function defaultSwaggerDecorators(): Function {
    return applyDecorators(
        ApiBearerAuth(),
        ApiResponse({
            status: HttpStatus.BAD_REQUEST,
            description:
                "The server cannot or will not process the request due to something that is perceived to be a client error (e.g., malformed request syntax, invalid request message framing, or deceptive request routing).",
        }),
        ApiResponse({
            status: HttpStatus.UNAUTHORIZED,
            description: "The request has not been applied because it lacks valid authentication credentials for the target resource.",
        }),
        ApiResponse({
            status: HttpStatus.NOT_FOUND,
            description:
                "The origin server did not find a current representation for the target resource or is not willing to disclose that one exists.",
        }),
        ApiResponse({
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            description: "The server encountered an unexpected condition that prevented it from fulfilling the request.",
        }),
    );
}
