import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from "@nestjs/common";
import { Observable } from "rxjs";

/**
 * The Redirect Interceptor to redirect the link
 *
 * @export
 * @class RedirectInterceptor
 * @implements {NestInterceptor}
 */
@Injectable()
export class RedirectInterceptor implements NestInterceptor {
    /**
     * Creates an instance of RedirectInterceptor.
     * @param {string} target
     * @memberof RedirectInterceptor
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly target: string) {}

    /**
     * global interceptor to redirect
     *
     * @param {ExecutionContext} context
     * @param {CallHandler} next
     * @returns {Observable<any>}
     * @memberof RedirectInterceptor
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        const response = context.switchToHttp().getResponse();
        response.redirect(this.target);
        return next.handle();
    }
}
