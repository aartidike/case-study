import { tap } from "rxjs/operators";
import { Injectable, NestInterceptor, ExecutionContext, CallHandler, Logger } from "@nestjs/common";
import { Observable } from "rxjs";

/**
 * The Response Time Interceptor class to Log the time took for each request
 *
 * @export
 * @class ResponseTimeInterceptor
 * @implements {NestInterceptor}
 */
@Injectable()
export class ResponseTimeInterceptor implements NestInterceptor {
    /**
     * Creates an instance of ResponseTimeInterceptor.
     * @param {Logger} logger
     * @memberof ResponseTimeInterceptor
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly logger: Logger) {}

    /**
     * To log the response time
     *
     * @param {ExecutionContext} context
     * @param {CallHandler} next
     * @returns {Observable<any>}
     * @memberof LoggingInterceptor
     */
    intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
        const now = Date.now();
        const TIME_IN_MS = 1000;
        const request = context.switchToHttp().getRequest();
        const fullUrl = `${request.protocol}://${request.get("host")}${request.originalUrl}`;
        return next
            .handle()
            .pipe(tap(() => this.logger.log(`Took ${(Date.now() - now) / TIME_IN_MS}s while accessing ${fullUrl}`, "ResponseTime")));
    }
}
