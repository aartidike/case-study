/* eslint-disable guard-for-in */
import { NestInterceptor, ExecutionContext, CallHandler, Injectable } from "@nestjs/common";
import { of } from "rxjs";
import { RedisService } from "nestjs-redis";
import { tap } from "rxjs/operators";
import * as moment from "moment";

import { CacheOptions } from "./interfaces/cache.options";
import { ConfigService } from "../../../modules/config/config.service";

/**
 * Redis interceptor to cache users list
 *
 * @export
 * @class RedisInterceptor
 * @implements {NestInterceptor}
 */
@Injectable()
export abstract class RedisInterceptor implements NestInterceptor {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private redisClient: any;

    protected abstract readonly options: CacheOptions;

    constructor(private readonly redisService: RedisService, private config: ConfigService) {
        this.redisClient = this.redisService.getClient();
    }

    /**
     * Redis service to get client info
     *
     * @param {ExecutionContext} context
     * @param {CallHandler} next
     * @returns
     * @memberof RedisInterceptor
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public async intercept(context: ExecutionContext, next: CallHandler): Promise<any> {
        try {
            const http = context.switchToHttp();
            const request = http.getRequest();
            if (!this.redisClient) {
                return next.handle();
            }
            if (request.query && request.query.cache === "false") {
                return next.handle();
            }
            const result = await this.redisClient.get(this.options.key);
            if (result) {
                return of(JSON.parse(result));
            }
            return next.handle().pipe(
                tap((value) => {
                    if (value) {
                        const ttl = this.options.ttl ? this.converToSeconds(this.options.ttl) : this.config.getRedis().ttl;
                        this.redisClient.set(this.options.key, JSON.stringify(value), "EX", ttl);
                    }
                }),
            );
        } catch {
            return next.handle();
        }
    }

    /**
     * To return time difference in seconds
     *
     * @private
     * @param {*} ttl
     * @returns {number}
     * @memberof RedisInterceptor
     */
    // eslint-disable-next-line class-methods-use-this
    private converToSeconds(ttl): number {
        const timeA = moment.utc(ttl, "H:mm:ss");
        const timeB = timeA.clone().startOf("day");
        return timeA.diff(timeB, "seconds");
    }
}
