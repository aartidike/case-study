/**
 * Cache Options
 *
 * @export
 * @interface CacheOptions
 */
export interface CacheOptions {
    ttl: string;
    key: string;
}
