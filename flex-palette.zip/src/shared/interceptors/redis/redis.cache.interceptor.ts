import { Injectable } from "@nestjs/common";
import { generate } from "shortid";
import { RedisInterceptor } from "./redis.interceptor";

// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-function-return-type
const makeInjectableMixin = (name: string) => (mixinClass) => {
    Object.defineProperty(mixinClass, "name", {
        value: `${name}-${generate()}`,
    });
    Injectable()(mixinClass);
    return mixinClass;
};

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type, @typescript-eslint/naming-convention, @typescript-eslint/explicit-module-boundary-types
export const RedisCacheInterceptor = (options) =>
    makeInjectableMixin("RedisInterceptor")(
        class extends RedisInterceptor {
            protected readonly options = options;
        },
    );
