import { Injectable, NestInterceptor, ExecutionContext, CallHandler, RequestTimeoutException } from "@nestjs/common";
import { Observable, throwError, TimeoutError } from "rxjs";
import { catchError, timeout } from "rxjs/operators";

/**
 * The Timeout Interceptor to handle the maximum execution time for the requests
 *
 * @export
 * @class TimeoutInterceptor
 * @implements {NestInterceptor}
 */
@Injectable()
export class TimeoutInterceptor implements NestInterceptor {
    /**
     * Creates an instance of TimeoutInterceptor.
     * @param {number} interval
     * @memberof TimeoutInterceptor
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly interval: number) {}

    /**
     * To set global request timeout
     *
     * @param {ExecutionContext} _context
     * @param {CallHandler} next
     * @returns {Observable<any>}
     * @memberof TimeoutInterceptor
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    intercept(_context: ExecutionContext, next: CallHandler): Observable<any> {
        if (this.interval > 0) {
            return next.handle().pipe(
                timeout(this.interval),
                catchError((error) => {
                    if (error instanceof TimeoutError) {
                        return throwError(
                            new RequestTimeoutException(
                                `The operation timed out. The operation has exceeded the time out limit ${this.interval} millisecond(s), though the server may still be processing the request.`,
                            ),
                        );
                    }
                    return throwError(error);
                }),
            );
        }
        return next.handle();
    }
}
