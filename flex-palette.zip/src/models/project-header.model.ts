import { Model, PrimaryKey, Column, DataType, Table } from "sequelize-typescript";

@Table({ tableName: "project_header", freezeTableName: true, timestamps: false, schema: "" })
export class ProjectHeaderModel extends Model<ProjectHeaderModel> {
    @PrimaryKey
    @Column({
        field: "proj_id",
        type: DataType.STRING,
    })
    projId: string;

    @Column({
        field: "prjnum",
        type: DataType.STRING,
        primaryKey: false,
    })
    prjNumber: string;

    @Column({
        field: "source",
        type: DataType.STRING,
        primaryKey: false,
    })
    source: string;

    @Column({
        field: "end_use",
        type: DataType.STRING,
        primaryKey: false,
    })
    endUse: string;
}
