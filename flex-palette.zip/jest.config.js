module.exports = {
    moduleFileExtensions: ["js", "json", "ts"],
    rootDir: "src",
    testRegex: ".spec.ts$",
    transform: {
        "^.+\\.(t|j)s$": "ts-jest",
    },
    coverageDirectory: "../coverage",
    testEnvironment: "node",
    collectCoverage: true,
    collectCoverageFrom: [
        "**/*.{ts,tsx}",
        "!**/*.spec.{ts,tsx}",
        "!**/main.ts",
        "!**/webapi.ts",
        "!**/modules/config/**",
        "!**/shared/**/*.{ts,tsx}",
    ],
    coverageReporters: ["lcov"],
    coveragePathIgnorePatterns: [
        ".module.ts$"
    ],
    reporters: [
        "default",
        [
            "jest-sonar",
            {
                outputDirectory: "reports/test",
                outputName: "testresults.xml",
            },
        ],
    ],
    testTimeout: 15000,
};
