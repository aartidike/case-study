/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */
const webpack = require("webpack");
const path = require("path");
const nodeExternals = require("webpack-node-externals");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const PACKAGE = require("./package.json");
const dotenv = require("dotenv");
const envFile = dotenv.config().parsed;

const banner = `${PACKAGE.name} - ${PACKAGE.version}`;

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
module.exports = (options) => {
    return {
        optimization: {
            minimize: false,
        },
        mode: "production",
        entry: ["webpack/hot/poll?100", "./src/main.ts"],
        watch: false,
        target: "node",
        externals: [
            nodeExternals({
                allowlist: ["webpack/hot/poll?100"],
            }),
        ],
        module: {
            rules: [
                {
                    test: /.tsx?$/,
                    use: "ts-loader",
                    exclude: /node_modules/,
                },
            ],
        },
        resolve: {
            extensions: [".tsx", ".ts", ".js"],
        },
        plugins: [
            new webpack.HotModuleReplacementPlugin(),
            new webpack.BannerPlugin(banner),
            new CopyWebpackPlugin({
                patterns: [
                    {
                        from: "package.json",
                        to: ".",
                    },
                    {
                        from: "package-lock.json",
                        to: ".",
                    },
                    {
                        from: ".npmrc",
                        to: ".",
                    },
                    {
                        from: ".env",
                        to: ".",
                    },
                    {
                        from: `./environment/config.${envFile.environment}.json`,
                        to: `./config/config.${envFile.environment}.json`,
                    },
                ],
            }),
        ],
        output: {
            path: path.join(__dirname, "dist"),
            filename: `${PACKAGE.name}.js`,
        },
    };
};
