const { Router } = require("express");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUI = require("swagger-ui-express");
var express = require("express");
const router = Router();

/**
 * @swagger
 * definitions:
 *  Loan:
 *   type: object
 *   properties:
 *    loanType:
 *     type: string
 *     description: loan type  of the user
 *     example: 'home loan'
 *    loanAmount:
 *     type: number
 *     description: loan amount of the user
 *     example: 10000
 *    date:
 *     type: date
 *     description: loan date of the user
 *     example: '05/11/1999'
 *    rateOfInterest:
 *     type: number
 *     description: rate of interest
 *     example: 10
 *    durationOfLoan:
 *     type: number
 *     description: duration of loan
 *     example: 1   
 */

/**
 * @swagger
 * components:
 *  securitySchemes:
 *    ApiKeyAuth:
 *     type: apiKey
 *     in: header
 *     name: authorization
 * /allLoans:
 *  get:
 *   security:
 *    - ApiKeyAuth: []
 *   summary: Get loan details of the customer
 *   description: display the loan details
 *   responses:
 *    200:
 *     description: success
 *    500:
 *     description: error
 */

/**
 * @swagger
 * components:
 *  securitySchemes:
 *    ApiKeyAuth:
 *     type: apiKey
 *     in: header
 *     name: authorization
 * /applyloan/:_id:
 *  post:
 *   security:
 *    - ApiKeyAuth: []
 *   summary: Apply for laon
 *   description: registered user can apply for loan
 *   requestBody:
 *    content:
 *     application/json:
 *      schema:
 *       $ref: '#/definitions/Loan'   
 *   responses:
 *    200:
 *     description: loan added succesfully
 *    500:
 *     description: failure in adding loan
 */

 module.exports = router;
      