const { Router } = require("express");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUI = require("swagger-ui-express");
var express = require("express");
const router = Router();

/**
 * @swagger
 * definitions:
 *  Customer:
 *   type: object
 *   properties:
 *    name:
 *     type: string
 *     description: name of the user
 *     example: 'Aarti'
 *    username:
 *     type: string
 *     description: Username of the user
 *     example: 'aarti'
 *    password:
 *     type: string
 *     description: password of the user
 *     example: 'aarti@123'
 *    address:
 *     type: string
 *     description: address of the user
 *     example: 'digras'
 *    state:
 *     type: string
 *     description: State of the user
 *     example: 'Maharashtra'
 *    country:
 *     type: string
 *     description: country of the user
 *     example: 'India'
 *    email:
 *     type: string
 *     description: email of the user
 *     example: 'aarti213@gmail.com'
 *    pan:
 *     type: string
 *     description: Pan details of the user
 *     example: 'XYZ123456'
 *    contact:
 *     type: string
 *     description: contact number of the user
 *     example: 9158902765
 *    dob:
 *     type: date
 *     description: Birth date of the user
 *     example: '21/12/1998'
 *    account_type:
 *     type: enum
 *     description: account type of the user
 *     example: 'saving account'
 */
  
/**
 * @swagger
 * /register:
 *  post:
 *   summary: register user
 *   description: register user for the Bank Management System
 *   requestBody:
 *    content:
 *     application/json:
 *      schema:
 *       $ref: '#/definitions/Customer'
 *   responses:
 *    200:
 *     description: customer registered succesfully...
 *    500:
 *     description: failure in creating employee
 */

/**
 * @swagger
 * /login:
 *  post:
 *   summary: login user
 *   description: login user for the Bank Management System
 *   requestBody:
 *    content:
 *     application/json:
 *      schema:
 *       $ref: '#/definitions/Customer'
 *   responses:
 *    200:
 *     description: token
 *    500:
 *     description: failure in login user
 */

/**
 * @swagger
 * components:
 *  securitySchemes:
 *    ApiKeyAuth:
 *     type: apiKey
 *     in: header
 *     name: authorization
 * /update/:username:
 *  put:
 *   security:
 *    - ApiKeyAuth: []
 *   summary: update user
 *   description: update the current
 *   consumes:
 *    - application/json
 *   produces:
 *    - application/json
 *   parameters:
 *    - in: body
 *      name: body
 *      required: true
 *      description: body object
 *      schema:
 *       $ref: '#/definitions/Customer'
 *   requestBody:
 *    content:
 *     application/json:
 *      schema:
 *       $ref: '#/definitions/Customer'
 *   responses:
 *    200:
 *     description: success
 *     content:
 *      application/json:
 *       schema:
 *        $ref: '#/definitions/Customer'
 */

/**
 * @swagger
 * components:
 *  securitySchemes:
 *    ApiKeyAuth:
 *     type: apiKey
 *     in: header
 *     name: authorization
 * /logout:
 *  post:
 *   security:
 *    - ApiKeyAuth: []
 *   summary: Logout user
 *   description: Logout The customer
 *   responses:
 *    200:
 *     description: success
 *    500:
 *     description: error
 */

 module.exports = router;