// var request = require('supertest');
// var app=require('../index');


// //applyloan
// describe('POST: /applyLoan',() => {
//     test('apply loan fail', async() => {
//     await request(app).post('/applyloan/:_id')
//     .expect(403)
//     })

//     test('apply loan success', async () => {
//         const data = {
//          loanType:"education",
//           loanAmount:6000,
//           date:"21/12/2023",
//           rateOfInterest:7,
//           durationOfLoan:2
//          }
//         await request(app).post('/applyloan/:_id')
//         .send(data)
//         .expect(200)
//         })
// })

// //allloans
// describe('POST: /allLoans',() => {
//     test('get loan fail', async() => {
//     await request(app).get('/allLoans')
//     .expect(200)
//     })
// test('get loan success', async () => {
//         await request(app).get('/allLoans')
//         .expect(200)
//         })
// })
