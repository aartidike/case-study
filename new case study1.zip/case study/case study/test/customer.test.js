var request = require('supertest');
var app=require('../index');
var cus=require('../controller/CustomerController');
const { response } = require('express');


const data = {
            name: 'pari',
            username: 'p@123',
            password: 'p@123',
            address: 'digras',
            state: 'maharashtra',
            country: 'india',
            email: 'aarti@gmail.com',
            pan: 'PAN123X56',
            contact: '78885467870',
            dob: "21/12/1998",
            account_type: 'Savings'
            }
loginDetails={
    username: 'p@123' ,
    password: 'p@123'
}
beforeAll((done) => {
   
    request(app).post('/register')
        .send(data)
        .end((err, response) => {
            done();
        })
})
beforeEach((done) => {
    request(app).post('/login')
        .send(loginDetails)
        .end((err, res) => {
            token = res.body.token;
        console.log("token" +token); // saving the token
            done();
        })
}) 

//Test Cases for view customer
describe('GET: /api/customer/viewCustomer', () => {
    test('get user details - failure', async () => {
        await request(app)
            .get('/allcustomers')
            .expect(401)
    })

    test('get user details successful', async () => {
        await request(app)
            .get('/allcustomers')
            .set('authorization', token)
            .expect(200)
    })

});
// function createLoginToken(server, loginDetails, done) {
//     request(server)
//         .post('/login')
//         .send(loginDetails)
//         .end(function(error, response) {
//             if (error) {
//                 throw error;
//             }
      
//             let loginToken = response.body.token;
//             done(loginToken);
//         });
// }
// it('should get all the meals', (done) => {
 
//     createLoginToken(app, {username: cus.username, password: 'secret'}, function(header) {
//         request(app)
//             .get('/allcustomers')
//             .set('authorization', header)
//             .expect(200)
//             .expect((res) => {
//                 expect(res.body.length).toBe(2);
//             })
//             .end(done);
//     });
// });










// //register
// describe('POST: /register',() => {
//     test('user register fail', async() => {
//     await request(app).post('/register')
//     .expect(400)
//     })

//     test('user register success', async () => {
//         const data = {
//         name: 'pari',
//         username: 'p@123',
//         password: 'p@123',
//         address: 'digras',
//         state: 'maharashtra',
//         country: 'india',
//         email: 'aarti@gmail.com',
//         pan: 'PAN123X56',
//         contact: 78885467870,
//         dob: "21/12/1998",
//         account_type: 'Savings'
//         }
//         await request(app).post('/register')
//         .send(data)
//         .expect(201)
//         })
       
    
//     test('customer already exist', async () => {
//     const data = {
//     name: 'aarti',
//     username: 'aarti@123',
//     password: 'aarti@123',
//     address: 'digras',
//     state: 'maharashtra',
//     country: 'india',
//     email: 'aarti@gmail.com',
//     pan: 'PAN123X56',
//     contact: 78885467870,
//     dob: "21/12/1998",
//     account_type: 'Savings'
//     }
//     await request(app).post('/register')
//     .send(data)
//     .expect(409)
//     })

//     test('required parameter missing ', async () => {
//         const data = {
//         address: 'digras',
//         state: 'maharashtra',
//         country: 'india',
//         email: 'aarti@gmail.com',
//         pan: 'PAN123X56',
//         contact: 78885467870,
//         dob: "21/12/1998",
//         account_type: 'Savings'
//         }
//         await request(app).post('/register')
//         .send(data)
//         .expect(400)
//         })
//        })


    
//    //login
    
//    describe('POST: /login',() => {
//     test('user login fail', async() => {
//     await request(app).post('/login')
//     .expect(400)
//     })
    
//     test('user login success', async () => {
//            const data = {
//                 username: 'john',
//                 password: 'john'
//                }
//            await request(app).post('/login')
//            .send(data)
//            .expect(200)
//            })

//      test('Invalid credentials', async () => {
//          const data = {
//              username: 'john',
//              password: 'johnjohn'
//             }
//             await request(app).post('/login')
//             .send(data)
//             .expect(400)
//             })

//         })
//      //update
//      describe('Put: /update',() => {
//      test('update fail ', async () => {
//         await request(app).put('/update/:username')
//         .expect(403)
//         })

//         test('update success ', async () => {
//             const data = {
//             address: 'digras',
//             state: 'maharashtra',
//             country: 'india',
//             email: 'aarti@gmail.com',
//             pan: 'PAN123X56',
//             contact: 78885467870,
            
//             account_type: 'Savings'
//             }
//             await request(app).put('/update/:username')
//             .send(data)
//             .expect(200)
//             })
//     })

//       //get all customers
    // describe('GET: /allcustomers',() => {
    //     test('get all customer success', async() => {
    //     await request(app).get('/allcustomers')
    //     .expect(401)
    //     })
    //     test('get all customer success', async() => {
    //         await request(app).get('/allcustomers')
    //         .set('Authorization', 'Bearer ' + token)
    //         .expect(200) 
    //     })
    // })
      
//     //logout
//     describe('POST: /logout',() => {
//         test('logout success', async() => {
//             const data={
//                 username:"john",
//                 password:"john"
//             }
//         await request(app).post('/logout').send(data)
//         .expect(200)
//         })
//         test('logout fail', async() => {
//             await request(app).post('/logout')
//             .expect(400)
//         })
//     })
    // describe('My API tests', function() {

    //     var token = null;
      
    //     before(function(done) {
    //       request(url)
    //         .post('/login')
    //         .send({ username: user1.username, password: user1.password })
    //         .end(function(err, res) {
    //           token = res.body.token; // Or something
    //           done();
    //         });
    //     });
      
    //     it('should get a valid token for user: user1', function(done) { 
    //       request('/allcustomers')
    //         .set('Authorization', 'Bearer ' + token)
    //         .expect(200, done);
    //     });
    //   });
     













































