const mongoose = require('mongoose');

var Schema = mongoose.Schema;

var customersSchema = new Schema({
    name:String,
    username: {type:String,required:true},
    password:String,
    address:String,
    state:String,
    country:String,
 	  email:String,
 	  pan:String,
 	  contact:String,
 	  dob:String,
    account_type:String

  //  customer:{type:String,required:true}

});

module.exports = mongoose.model('Customer', customersSchema);




