//var mongoose = require('mongoose');
//var Schema = mongoose.Schema;

//var loansSchema = new Schema({
//    username: String,
  //  Customer:[
    //  {type: Schema.Types.ObjectId, ref: 'Customer'}
    //]
//});
//module.exports = mongoose.model('Loans', loansSchema);

const Joi = require('joi');
 const mongoose = require('mongoose'); 
 const Schema=mongoose.Schema;
 const loanSchema = new Schema({
  
    
     loanType: {
         type:String,
      required:true
    },
 
   loanAmount: {
        type:Number,
         required:true,
         minLength:5,
         maxLength:8
     },
    
     date: {
         type:String,
         required:true
     },
    
     rateOfInterest: {
         type:Number,
         required:true
    },
 
    durationOfLoan: {
        type:Number,
         required:true
     },
    username:[
       {type: String}
        ]
   
 });
  module.exports = mongoose.model("Loans", loanSchema);