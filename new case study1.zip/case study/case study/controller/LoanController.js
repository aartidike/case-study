require("dotenv").config();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const mongoose = require('mongoose')
const Loan = require("../model/Loans.js");
const Customer=require("../model/Customer.js");
const auth = require("../middleware/auth.js");


const app = express();

//get all loans
exports.findAll= async (req,res)=> {
  Loan.find({})
  .then(function(dbProducts) {
    res.json(dbProducts);
  })
  .catch(function(err) {
    res.json(err);
  })
};

  //apply for loans
   exports.create=async (req,res) => {
     data=""
    try{
      await Customer.findById({_id:req.params._id})
          .then((response) => {
         data=response.username
        })
      }
        catch(error){
          console.log(error)
        } 
   try{
       const loan = await Loan.create({
      //_id:req.params._id,
        username:data,
        loanType:req.body.loanType,
        loanAmount: req.body.loanAmount,
        date:req.body.date,
        rateOfInterest:req.body.rateOfInterest,
        durationOfLoan:req.body.durationOfLoan
       });
       
       res.status(200).send(loan);
     }catch(error){
       console.log(error)
     }
  
    }


 
 
    
  
  
  
