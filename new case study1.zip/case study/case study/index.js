const express = require('express');
const bodyParser = require('body-parser');

// create express app
const app = express();
app.use(bodyParser.json()) // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true }))
require('./routes/allroutes')(app);
const swaggerUI=require('swagger-ui-express');
const swaggerJSDoc=require('swagger-jsdoc');

const swagger=require('./swagger/CustomerSwagger');
const swagger1=require('./swagger/LoanSwagger');

// Configuring the database
const dbConfig = require('./config/database.config.js');
 const mongoose = require('mongoose');

module.exports = {
    Loans: require("./model/Loans"),
    Customer: require("./model/Customer")
  };
  const swaggerOptions = {
    definition: {
      openapi: "3.0.0",
      info: {
        title: "Bank Management System",
        version: "1.0.0",
        description: "User Api for Bank Management System",
        contact: {
          name: "Aarti Dike",
          email: "aartidike213@gmail.com",
        },
        servers: ["http://localhost:4000"],
      },
    },
    apis: ["../case study/swagger/CustomerSwagger.js","../case study/swagger/LoanSwagger.js"]
  };
  const swaggerDocs = swaggerJSDoc(swaggerOptions);
  app.use(swagger);
  app.use(swagger1);
  app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerDocs));
 // mongoose.Promise = global.Promise;
                                                                                      
  // Connecting to the database
mongoose.connect(dbConfig.url, {
	useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

// listen for requests
const server=app.listen(4000, () => {
    console.log("Server is listening on port 4000");
});
module.exports = app;

