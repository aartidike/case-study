var MongoClient = require('mongodb').MongoClient;
module.exports = {
  url: 'mongodb+srv://aarti:demo@cluster0.vg0qw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}

