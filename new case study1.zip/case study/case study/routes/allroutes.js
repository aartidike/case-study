const auth=require('../middleware/auth');
module.exports = (app) => {
    const cus = require('../controller/CustomerController');
    const loan = require('../controller/LoanController');
    
    //api routes for loans
    // apply loan
    app.post('/applyloan/:_id',auth,loan.create);
    //retrieve all loans
    app.get("/allLoans",loan.findAll);
    

    //api routes for customers
    // Retrieve all customers
    app.get('/allcustomers',auth,cus.findAll);
    //register
    app.post('/register', cus.create);
    // login
    app.post('/login',cus.findOne);
    //logout
    app.post('/logout',cus.find);
    //Update 
    app.put('/update/:username',auth,cus.findOneAndUpdate);
    
}