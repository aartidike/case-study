export interface DefaultDBProperties {
    /**
     * The host of the database
     *
     * @type {string}
     * @memberof DefaultDBProperties
     */
    host: string;

    /**
     * The usename of the database
     *
     * @type {string}
     * @memberof DefaultDBProperties
     */
    username: string;

    /**
     * The password of the database
     *
     * @type {string}
     * @memberof DefaultDBProperties
     */
    password: string;

    /**
     * The name of the database
     *
     * @type {string}
     * @memberof DefaultDBProperties
     */
    database: string;

    /**
     * The type/dialect of the database
     *
     * @type {string}
     * @memberof DefaultDBProperties
     */
    type: string;

    /**
     * To set whether logging is needed or not
     *
     * @type {boolean}
     * @memberof DefaultDBProperties
     */
    logging: boolean;
}
