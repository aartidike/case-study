/**
 * To get the MDR URL
 *
 * @export
 * @interface MDRURL
 */
export interface MDRURL {
    /**
     * The URL for MDR
     *
     * @type {string}
     * @memberof MDRURL
     */
    url: string;
}

/**
 * To get the MDR Details
 *
 * @export
 * @interface MDR
 */
export interface MDR {
    /**
     * MDR URL
     *
     * @type {MDRURL}
     * @memberof MDR
     */
    user: MDRURL;
}
