import { DefaultDBProperties } from "./database-properties";

/**
 * DB connections of the application
 *
 * @export
 * @interface DBConnections
 */
export interface DBConnections {
    /**
     * The default DB connection properties
     *
     * @type {DefaultDBProperties}
     * @memberof DBConnections
     */
    appDBConnection: DefaultDBProperties;
}
