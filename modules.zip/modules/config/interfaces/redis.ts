/**
 * Redis configurations
 *
 * @export
 * @interface RedisConfig
 */
export interface RedisConfig {
    /**
     * Redis hostname
     *
     * @type {string}
     * @memberof RedisConfig
     */
    name: string;

    /**
     * Redis url
     *
     * @type {string}
     * @memberof RedisConfig
     */
    url: string;

    /**
     * RedisConfig accesskey
     *
     * @type {string}
     * @memberof RedisConfig
     */
    accessKey?: string;

    /**
     * RedisConfig default ttl
     *
     * @type {string}
     * @memberof RedisConfig
     */
    ttl: string;

    /**
     * maxRetriesPerRequest
     *
     * @type {number}
     * @memberof RedisConfig
     */
    maxRetriesPerRequest: number;

    /**
     * retryStrategy
     *
     * @type {number}
     * @memberof RedisConfig
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    retryStrategy: any;
}
