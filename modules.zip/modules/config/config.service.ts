import * as Joi from "@hapi/joi";
import { Logger, Injectable } from "@nestjs/common";
import * as nconf from "nconf";
import { readJsonSync } from "fs-extra";
import * as config from "dotenv";
import { Environment } from "../../enums";
import { ValidatorSchema } from "../../shared/schema/validator.schema";
import { Config, DefaultDBProperties, OktaConfig, MDR } from "./interfaces";
import { RedisConfig } from "./interfaces/redis";

/**
 * Service to load environment based configurations
 *
 * @export
 * @class ConfigService
 */
@Injectable()
export class ConfigService {
    /**
     * The get Config details
     *
     * @private
     * @type {Config}
     * @memberof ConfigService
     */
    private Config: Config;

    /**
     * To get the package object
     *
     * @private
     * @memberof ConfigService
     */
    private packageObj;

    /**
     * To Get the environment
     *
     * @private
     * @memberof ConfigService
     */
    private environment;

    /**
     * To get the filename
     *
     * @private
     * @memberof ConfigService
     */
    private filename;

    /**
     * Creates an instance of ConfigService.
     * @param {string} [filename]
     * @memberof ConfigService
     */
    constructor() {
        const file = "./package.json";
        const environmentConfig = config.config();
        this.packageObj = readJsonSync(file);
        this.environment = environmentConfig.parsed.environment;
        this.filename = this.getConfigurationFile();
        nconf.use("memory");
        if (!nconf.get("Config")) {
            this.setFile(this.filename);
        }
        const cachedConfig = nconf.get("Config");
        this.Config = this.validateInput(cachedConfig);
        const ERROR_MSG = "Unable to read the config or Config file is missing";
        if (!this.Config) {
            Logger.error("config", ERROR_MSG);
            throw new Error(ERROR_MSG);
        }
    }

    /**
     * Ensures all needed variables are set, and returns the validated JavaScript object
     * including the applied default values.
     *
     * @private
     * @param {*} envConfig
     * @returns
     * @memberof ConfigService
     */
    // eslint-disable-next-line class-methods-use-this
    private validateInput(environmentConfig): Config {
        const schema = new ValidatorSchema();
        const environmentVariablesSchema = Joi.object({
            Port: Joi.number().required(),
            RequestTimeout: Joi.number().required(),
            DBConnections: Joi.object()
                .keys({
                    appDBConnection: schema.getDBConnections(),
                })
                .required(),
            MDR: schema.getMDR(),
            OktaConfig: schema.getOktaConfig(),
            Redis: Joi.object().keys({
                name: Joi.string().required(),
                url: Joi.string().required(),
                ttl: Joi.string().required(),
                maxRetriesPerRequest: Joi.number().required(),
                retryStrategy: Joi.number().required(),
            }),
        });

        const { error, value: validatedEnvironmentConfig } = environmentVariablesSchema.validate(environmentConfig);
        if (error) {
            throw new Error(`Config validation error: ${error.message}`);
        }
        return validatedEnvironmentConfig;
    }

    /**
     * To set the file
     *
     * @private
     * @param {string} filename
     * @memberof ConfigService
     */
    // eslint-disable-next-line class-methods-use-this
    private setFile(filename: string): void {
        nconf.file("Config", {
            file: filename,
            dir: "./config/",
            search: true,
        });
        if (!nconf.get("Config")) {
            nconf.file("Config", {
                file: `environment/${filename}`,
                dir: __dirname,
                search: true,
            });
        }
    }

    /**
     * To Get the config object
     *
     * @returns {Config}
     * @memberof ConfigService
     */
    public getConfig(): Config {
        return this.Config;
    }

    /**
     * To get the database connection object
     *
     * @param {string} connection
     * @returns {DefaultDBProperties}
     * @memberof ConfigService
     */
    public getDatabase(connection: string): DefaultDBProperties {
        // eslint-disable-next-line security/detect-object-injection
        return this.Config.DBConnections[connection];
    }

    /**
     * To get the application config
     *
     * @returns {AppConfig}
     * @memberof ConfigService
     */
    public getApp(): { name; description; version; environment } {
        return {
            name: this.packageObj.name,
            description: this.packageObj.description,
            version: this.packageObj.version,
            environment: this.environment,
        };
    }

    /**
     * To get the MDR config
     *
     * @returns {MDR}
     * @memberof ConfigService
     */
    public getMdr(): MDR {
        return this.Config.MDR;
    }

    /**
     * To get the Port
     *
     * @returns {number}
     * @memberof ConfigService
     */
    public getPort(): number {
        return this.Config.Port;
    }

    /**
     * To get the Okta Configurations
     *
     * @returns {OktaConfig}
     * @memberof ConfigService
     */
    public getOktaConfig(): OktaConfig {
        return this.Config.OktaConfig;
    }

    /**
     * To get the Redis Config
     *
     * @returns {RedisConfig}
     * @memberof ConfigService
     */
    public getRedis(): RedisConfig {
        return this.Config.Redis;
    }

    private getConfigurationFile(): string {
        let fileName;
        switch (this.environment) {
            case Environment.development:
                fileName = "config.dev.json";
                break;
            case Environment.qas:
                fileName = "config.qas.json";
                break;
            case Environment.production:
                fileName = "config.prod.json";
                break;
            default:
                fileName = "config.local.json";
                break;
        }

        return fileName;
    }
}
