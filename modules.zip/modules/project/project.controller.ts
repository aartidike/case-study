import { Controller, Get, HttpStatus, Query } from "@nestjs/common";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { defaultSwaggerDecorators } from "../../shared/decorators/swagger.decorator";
import { ProjectService } from "./project.service";

/**
 * The project controller is the controller in project module
 *
 * @export
 * @class ProjectController
 * @extends {ConfigService}
 */
@defaultSwaggerDecorators()
@ApiTags("project")
@Controller("project")
export class ProjectController {
    constructor(private projectService: ProjectService) {}

    /**
     * To get the Project Information
     *
     * @returns
     * @memberof ProjectController
     */
    @Get("info")
    @ApiOperation({
        summary: "Returns Project information",
        description: "Get Project information by Project ID based on a Source and Project Number",
    })
    @ApiResponse({
        status: HttpStatus.OK,
        description: "Get Project Information",
    })
    async getProjectInfo(@Query("projSource") projSource: string, @Query("projNumber") projNumber: string): Promise<any> {
        const data = await this.projectService.getProject(projSource, projNumber);
        return data;
    }
}
