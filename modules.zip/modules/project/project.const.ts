export const projectConst = {};

export const projectQuery = {
    projectInfo: `select proj_id, end_use from project_header where source=? and prjnum=?;`,
};
