import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { ProjectHeaderModel } from "../../models/project-header.model";

@Injectable()
export class ProjectService {
    constructor(@InjectModel(ProjectHeaderModel) private ProjectModel: typeof ProjectHeaderModel) {}

    public async getProject(projSource: string, projNumber: string): Promise<any> {
        return this.ProjectModel.findOne({ attributes: ["projId", "endUse"], where: { source: projSource, prjNumber: projNumber } });
    }
}
