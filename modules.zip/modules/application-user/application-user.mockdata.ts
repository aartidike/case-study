/**
 * Mock testing varible of application-user
 */
export const APPLICATION_USER_MOCK_DATA = {
    findAllResponse: [
        {
            dataValues: {
                createdBy: "",
                createdOn: new Date().getDate(),
                updatedBy: "",
                updatedOn: new Date().getDate(),
                userId: 1,
                globalUserId: "GXR9790",
                isActive: 1,
                fullName: "Jones",
                email: "jones@iff.com",
            },
            globalUserId: "GXR9790",
        },
    ],
    createApplicationUser: {
        globalUserId: "GXR9790",
        isActive: 1,
    },
    findOne: {
        dataValues: {
            createdBy: "",
            createdOn: new Date().getDate(),
            updatedBy: "",
            updatedOn: new Date().getDate(),
            userId: 1,
            globalUserId: "GXR9790",
            isActive: 1,
        },
        globalUserId: "GXR9790",
    },
    request: {
        headers: {
            authorization: "test",
        },
    },
    requestFalseToken: {
        headers: {
            authorization: undefined,
        },
    },
    mapUser: {
        createdBy: "",
        createdOn: new Date(),
        updatedBy: "",
        updatedOn: new Date(),
        userId: 1,
        globalUserId: "GXR9790",
        isActive: 1,
    },
};
