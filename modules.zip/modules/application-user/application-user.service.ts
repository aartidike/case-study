/* eslint-disable dot-notation */
import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { find, map as _map } from "lodash";
import { InjectModel } from "@nestjs/sequelize";
import { ApplicationUser } from "../../models/application-user.model";
import { ApplicationUserRequestDto } from "../../dtos/application-user.request.dto";
import { ApplicationUserResponseDto } from "../../dtos/application-user.response.dto";
import { MDRUsersService } from "../mdr/mdr-user.service";

/**
 * Class ApplicationUser Service
 *
 * @export
 * @class ApplicationUserService
 */
@Injectable()
export class ApplicationUserService {
    /**
     *Creates an instance of ApplicationUserService.
     * @param {typeof ApplicationUser} applicationUserModel
     * @param {MDRUsersService} mdrUsersService
     * @memberof ApplicationUserService
     */
    constructor(
        @InjectModel(ApplicationUser)
        private applicationUserModel: typeof ApplicationUser,
        private readonly mdrUsersService: MDRUsersService, // eslint-disable-next-line no-empty-function
    ) {}

    /**
     * To get the applicationUser details
     *
     * @returns {Promise<ApplicationUserResponseDto[]}
     * @memberof Promise<ApplicationUserService>
     */
    async findAll(): Promise<ApplicationUserResponseDto[]> {
        const result = await this.applicationUserModel.findAll<ApplicationUser>();
        if (result && result.length > 0) {
            const userIds = _map(result, "globalUserId");
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const userDetails: any = await this.mdrUsersService.getMultipleUserDetailsByUserIds(userIds.toString());
            if (userDetails) {
                _map(result, (item) => {
                    const user = find(userDetails.users, ["globaluserid", item["dataValues"].globalUserId]);
                    if (user) {
                        Object.assign(item["dataValues"], { fullName: user.fullname, email: user.email });
                    }
                    return item;
                });
            }
        }
        return result;
    }

    /**
     * To Get the applicationUser details based on ApplicationUser Id
     *
     * @param {number} applicationUserId
     * @returns {Promise<ApplicationUserResponseDto}
     * @memberof Promise<ApplicationUserService>
     */
    async findOne(applicationUserId: number): Promise<ApplicationUserResponseDto | null> {
        const result = await this.applicationUserModel.findOne<ApplicationUser>({
            where: { userId: applicationUserId },
        });
        const response = await this.mapUserData(result);
        return response;
    }

    /**
     * To Get the applicationUser details based on ApplicationUser Id
     *
     * @param {number} mdrUserId
     * @returns {Promise<ApplicationUserResponseDto}
     * @memberof Promise<ApplicationUserService>
     */
    async findOneByMdrUserId(mdrUserId: number): Promise<ApplicationUserResponseDto | null> {
        const result = await this.applicationUserModel.findOne<ApplicationUser>({
            where: { globalUserId: mdrUserId },
        });
        const response = await this.mapUserData(result);
        return response;
    }

    /**
     * To Create the applicationUser details
     *
     * @param {ApplicationUserDto} applicationUserDto
     * @returns {Promise<void>}
     * @memberof ApplicationUserService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    async create(applicationUserDto: any): Promise<void> {
        const result = await this.applicationUserModel.create(applicationUserDto);
        await result.save();
    }

    /**
     * To update the applicationUser details by ApplicationUser Id
     *
     * @param {number} applicationUserId
     * @param {ApplicationUserDto} applicationUser
     * @returns {Promise<void>}
     * @memberof ApplicationUserService
     */
    async update(applicationUserId: number, applicationUserDto: ApplicationUserRequestDto): Promise<void> {
        const result = await this.applicationUserModel.findByPk<ApplicationUser>(applicationUserId);
        if (result) {
            Object.assign(result, applicationUserDto);
            await result.save();
        }
    }

    /**
     * To Get the Current User Details
     *
     * @param {string} token
     * @returns {Promise<any>}
     * @memberof ApplicationUserService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async getCurrentUser(token: string): Promise<any> {
        const user = await this.mdrUsersService.getCurrentUser(token);
        if (!user) {
            throw new HttpException("Invalid User ID.", HttpStatus.BAD_REQUEST);
        }
        const result = await this.findOneByMdrUserId(user["globaluserid"]);
        return result;
    }

    /**
     * To Map the Application and MDR user data
     *
     * @param {*} result
     * @returns {Promise<any>}
     * @memberof ApplicationUserService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async mapUserData(result: any | null): Promise<any | null> {
        if (!result) {
            return result;
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const userDetails: any = await this.mdrUsersService.getMultipleUserDetailsByUserIds(result["dataValues"].globalUserId);
        if (!userDetails) {
            return result;
        }
        const user = find(userDetails.users, ["globaluserid", result["dataValues"].globalUserId]);
        if (user) {
            Object.assign(result["dataValues"], { fullName: user.fullname, email: user.email });
        }
        return result;
    }
}
