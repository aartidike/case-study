/* eslint-disable import/newline-after-import */
/* eslint-disable unicorn/no-useless-undefined */
/* eslint-disable unicorn/no-null */
/* eslint-disable max-lines-per-function */
import { getModelToken } from "@nestjs/sequelize";
import { HttpService, HttpModule, HttpStatus } from "@nestjs/common";
import { of } from "rxjs";
import axios from "axios";
import MockAdapter from "axios-mock-adapter";
import { createReadStream } from "fs";
import { ApplicationUserService } from "./application-user.service";
import { ApplicationUserController } from "./application-user.controller";
import { ApplicationUser } from "../../models/application-user.model";
import { MOCK_DATA } from "../mdr/mdr-user.mock.data";
import { MDRUsersService } from "../mdr/mdr-user.service";
import { ConfigModule } from "../config/config.module";
import { MDRModule } from "../mdr/mdr.module";
import { ApplicationUserResponseDto } from "../../dtos/application-user.response.dto";
import { APPLICATION_USER_MOCK_DATA } from "./application-user.mockdata";

// eslint-disable-next-line import/order
import path = require("path");
const mockAdapter = new MockAdapter(axios);
describe("ApplicationUser", () => {
    let applicationUserService: ApplicationUserService;
    let module: TestingModule;
    let applicationUserController: ApplicationUserController;
    let httpService: HttpService;

    beforeAll(async () => {
        module = await Test.createTestingModule({
            controllers: [ApplicationUserController],
            providers: [
                {
                    provide: MDRUsersService,
                    useValue: {
                        // eslint-disable-next-line unicorn/no-useless-undefined
                        getCurrentUser: jest.fn().mockResolvedValue(MOCK_DATA.currentUserData).mockResolvedValueOnce(undefined),
                        getMultipleUserDetailsByUserIds: jest
                            .fn()
                            .mockResolvedValue(MOCK_DATA.userData.data)
                            .mockResolvedValueOnce(undefined),
                        login: jest.fn(() => Promise.resolve(MOCK_DATA.userData.data)),
                        // getUserPhoto: jest.fn(() => Promise.reject()),
                        getUserPhoto: jest.fn().mockResolvedValue(
                            mockAdapter
                                .onGet(`https://ion-qas.iff.com/api/v1/users/GXR9790/photo?returnemptyimage=false`)
                                .reply(HttpStatus.OK, createReadStream(path.join(__dirname, "../../../environment/config.test.json")), {
                                    "Content-Type": "application/json",
                                }),
                        ),
                    },
                },
                ApplicationUserService,
                {
                    provide: getModelToken(ApplicationUser),
                    useValue: {
                        findOne: jest.fn().mockResolvedValue(APPLICATION_USER_MOCK_DATA.findOne),
                        create: jest.fn().mockResolvedValueOnce({ save: jest.fn() }),
                        findByPk: jest.fn().mockResolvedValue({ save: jest.fn() }).mockResolvedValueOnce(false),
                        update: jest.fn().mockResolvedValue(true).mockReturnValueOnce(false),
                        save: jest.fn(),
                        delete: jest.fn().mockResolvedValue(true),
                        findAll: jest.fn().mockResolvedValue([APPLICATION_USER_MOCK_DATA.findOne]).mockResolvedValueOnce([]),
                        mapUserData: jest.fn().mockResolvedValue(APPLICATION_USER_MOCK_DATA.findOne).mockResolvedValueOnce(null),
                    },
                },
            ],
            imports: [HttpModule, ConfigModule, MDRModule],
        }).compile();

        applicationUserService = module.get<ApplicationUserService>(ApplicationUserService);
        applicationUserController = module.get(ApplicationUserController);
        httpService = module.get<HttpService>(HttpService);
    });

    it("should be defined", () => {
        expect(applicationUserService).toBeDefined();
        expect(applicationUserController).toBeDefined();
        expect(httpService).toBeDefined();
    });

    describe("**** Current User ****", () => {
        it("** Should Check Invalid User **", async () => {
            try {
                await applicationUserService.getCurrentUser(APPLICATION_USER_MOCK_DATA.requestFalseToken.headers.authorization);
            } catch (error) {
                expect(error.message).toStrictEqual("Invalid User ID.");
            }
        });

        it("** Should Check Current User **", async () => {
            const result = await applicationUserController.getCurrentUser(APPLICATION_USER_MOCK_DATA.request);
            expect(MOCK_DATA.currentUserData).toMatchObject(result);
        });
    });

    describe("**** Map User Data ****", () => {
        it("** Should Check null **", async () => {
            const result = await applicationUserService.mapUserData(undefined);
            expect(result).toEqual(undefined);
        });

        it("** Should Find User **", async () => {
            const result = await applicationUserService.mapUserData(APPLICATION_USER_MOCK_DATA.findOne);
            expect(result).toEqual(APPLICATION_USER_MOCK_DATA.findOne);
        });
    });

    describe("**** Find All Application Users ****", () => {
        it("** Application Users Service Check Empty **", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const result = await applicationUserService.findAll();
            expect(result).toStrictEqual([]);
        });

        it("** Application Users Service Without User Data**", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const result = await applicationUserService.findAll();
            expect(APPLICATION_USER_MOCK_DATA.findAllResponse).toMatchObject(result);
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        it("** Application Users Service With User Data **", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const result = await applicationUserService.findAll();
            expect(APPLICATION_USER_MOCK_DATA.findAllResponse).toMatchObject(result);
        });

        it("** Application Users Controller **", async () => {
            const expectedResult = [new ApplicationUserResponseDto()];
            const mock = jest.spyOn(applicationUserService, "findAll");
            mock.mockImplementation(() => Promise.resolve(expectedResult));
            const response = await applicationUserController.GetAll();
            expect(response).toStrictEqual({ applicationUsers: expectedResult });
        });
    });

    describe("**** Find One By Application UserId ****", () => {
        it("** Application Users Service By Id**", async () => {
            jest.spyOn(httpService, "get").mockImplementationOnce(() => of(MOCK_DATA.userData));
            const mock = await applicationUserService.findOne(1);
            expect(APPLICATION_USER_MOCK_DATA.findOne).toBe(mock);
        });

        it("** Application Users Controller By Id **", async () => {
            const expectedResult = new ApplicationUserResponseDto();
            const mockNumberToSatisfyParameters = 1;
            const mock = jest.spyOn(applicationUserService, "findOne");
            mock.mockImplementation(() => Promise.resolve(expectedResult));
            const response = await applicationUserController.GetById(mockNumberToSatisfyParameters);
            expect(response).toBe(expectedResult);
        });
    });

    describe("**** Create Application User ****", () => {
        it("** Create Application User **", async () => {
            let isTested = false;
            try {
                await applicationUserController.Create(
                    APPLICATION_USER_MOCK_DATA.createApplicationUser,
                    APPLICATION_USER_MOCK_DATA.request,
                );
                isTested = true;
            } catch {
                isTested = false;
            }
            expect(isTested).toBe(true);
        });
    });

    describe("**** Update Application User By Id ****", () => {
        it("**** Update Application User By Id False ****", async () => {
            let isTested = false;
            try {
                await applicationUserController.Update(
                    1,
                    APPLICATION_USER_MOCK_DATA.createApplicationUser,
                    APPLICATION_USER_MOCK_DATA.request,
                );
                isTested = true;
            } catch {
                isTested = false;
            }
            expect(isTested).toBe(true);
        });
        // eslint-disable-next-line sonarjs/no-identical-functions
        it("**** Update Application User By Id ****", async () => {
            let isTested = false;
            try {
                await applicationUserController.Update(
                    1,
                    APPLICATION_USER_MOCK_DATA.createApplicationUser,
                    APPLICATION_USER_MOCK_DATA.request,
                );
                isTested = true;
            } catch {
                isTested = false;
            }
            expect(isTested).toBe(true);
        });
    });

    describe("**** Login to the system ****", () => {
        it("** Login to the system **", async () => {
            const result = await applicationUserController.login(APPLICATION_USER_MOCK_DATA.request);
            expect(result).toStrictEqual(MOCK_DATA.currentUserData);
        });
    });

    // describe("Get User Photo", () => {
    //     it("Should throw Http Exception", async () => {
    //         try {
    //             await applicationUserController.getUserPhoto({ userId: "GXR9790" }, "");
    //         } catch (error) {
    //             expect(error).toEqual("[TypeError: Cannot read property 'pipe' of undefined]");
    //         }
    //     });

    //     it("Should return photo of users based on id", async () => {
    //         const mock = new MockAdapter(axios);
    //         const data = { response: true };
    //         mock.onGet("https://ion-qas.iff.com/api/v1/users/GXR9790/photo?returnemptyimage=false").reply(HttpStatus.OK, data);
    //         const result = await mdrUsersService.getUserPhoto("GXR9790");
    //         expect(result.status).toEqual(HttpStatus.OK);
    //     });
    // });
});
