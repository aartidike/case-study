/**
 * MDRUser Mock data values
 *
 * Initialization of the variable MOCK_DATA
 */
export const MOCK_DATA = {
    userData: {
        data: { users: [{ name: "Davy Jones", globaluserid: "GXR9790", fullname: "Jones", email: "jones@iff.com" }] },
        status: 200,
        statusText: "",
        headers: {},
        config: {},
    },
    invalidUserData: {
        data: { users: [{ name: "Davy" }] },
        status: 404,
        statusText: "",
        headers: {},
        config: {},
    },
    currentUserData: {
        dataValues: {
            createdBy: "",
            createdOn: new Date().getDate(),
            updatedBy: "",
            updatedOn: new Date().getDate(),
            userId: 1,
            globalUserId: "GXR9790",
            isActive: 1,
            fullName: "Jones",
            email: "jones@iff.com",
        },
        globalUserId: "GXR9790",
    },
    userDataByEmail: {
        data: {},
        status: 200,
        statusText: "",
        headers: {},
        config: {},
    },
    jwt:
        "eyJraWQiOiJ4MWlzYTVMaGFFUGJKQkl3REZ1SjJ5b3duZFlybGsxcnJWVm1uTDZfVkdJIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiIwMHUxaG1zMXZ3Y05vT1pKUDBoOCIsIm5hbWUiOiJHb3d0aGFtIFJhaiIsImVtYWlsIjoiR09XVEhBTS5SQUpASUZGLkNPTSIsInZlciI6MSwiaXNzIjoiaHR0cHM6Ly9pZmYub2t0YS5jb20iLCJhdWQiOiIwb2ExaWhoZWo1blk2dlRTNTBoOCIsImlhdCI6MTU5MzQxMDQxMSwiZXhwIjoxNTkzNDE0MDExLCJqdGkiOiJJRC4xQkJtRVdzdDNpcDJGLV85LTBzNTI5Q3hIOFU3dG9teE42SG9ac2hwenNBIiwiYW1yIjpbInB3ZCIsImtiYSIsIm1mYSJdLCJpZHAiOiIwb2F4d2N0dWxlRlpQV1RCWllJViIsIm5vbmNlIjoiSVFjcTRGU0dHOVdheUFRRDk3OVgzUEZmZkpBN3NjY0dIZFYtWjZTUWhLTUh0IiwicHJlZmVycmVkX3VzZXJuYW1lIjoiZ3hyOTc5MEBnbG9iYWwuaWZmLmNvbSIsImF1dGhfdGltZSI6MTU5MzQxMDQwOCwiYXRfaGFzaCI6ImpkMWE5ZjlQNWxyVUVlMlpOcXpweHcifQ.NlB6wKPdz_1iMhihY5jCjvy_tfEoZ4BhWaknUE5cczPfhGljEoAwJWtVOJ5Ngu_hP0pBheRp1xzRilZNYBzQhBforZKlKUzlpuT1wfwoZXO0O0Go6XZev5UuVrasjy9yOBzt3u3FQG_fR1ml3wlV_IVcj13p6pvsT_jSTIiXUPOvBRs3r6uIuqRqU7ipY40osADcQcycBXd8MWJNFN6iav2W7HnhmE4hKU5K3GOsYQ2ipgHp_XOLDu3Q4BpCS5xwbmbOG7HTqy3drjOeAVz5xAOsR5Bzw_pG5MnNMtntR7FmZdP5qCLgTYQjMiFg7Hl6fbzM5A36HEG31wpSNYz-qg",
    userId: "GXR9790",
    emailId: "thangaraja.c@iff.com",
    notFound: "Request failed with status code 404",
};
