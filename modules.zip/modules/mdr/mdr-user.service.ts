import { Injectable, HttpService, HttpException, HttpStatus } from "@nestjs/common";
import { AxiosResponse } from "axios";
import { map } from "rxjs/operators";
import * as jwt from "jsonwebtoken";
import { ConfigService } from "../config/config.service";

/**
 * Class MDRUsersService to handle the users
 *
 * @export
 * @class MDRUsersService
 */
@Injectable()
export class MDRUsersService {
    /**
     * Creates an instance of MDRUsersService.
     * @param {ConfigService} config
     * @param {HttpService} httpService
     * @memberof MDRUsersService
     */
    // eslint-disable-next-line no-empty-function
    constructor(private readonly config: ConfigService, private readonly httpService: HttpService) {}

    /**
     * To Get the user details based on authorization userId
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersService
     */
    async getUserDetailsByUserID(userId: string): Promise<AxiosResponse> {
        return this.findUser(userId).then((result) => {
            return result.data.users[0];
        });
    }

    /**
     * To Get the user details based on emails
     *
     * @Query email
     * @returns
     * @memberof MDRUsersService
     */
    async getUserDetailsByEmail(emailids: string): Promise<AxiosResponse> {
        if (!emailids) {
            throw new HttpException("Provide Email Id(s)", HttpStatus.BAD_REQUEST);
        }
        return this.findUserByEmailIds(emailids).then((result) => result.data);
    }

    /**
     * To Get the user photo based on authorization userId
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersService
     */
    async getUserPhoto(userId: string): Promise<AxiosResponse> {
        try {
            const mdrURL = this.config.getMdr().user.url;
            return await this.httpService
                .get(`${mdrURL}${userId}/photo?returnemptyimage=false`, {
                    method: "GET",
                    responseType: "stream",
                })
                .toPromise();
        } catch {
            throw new HttpException("Image Not Found", HttpStatus.NOT_FOUND);
        }
    }

    /**
     * To Get the user id from the jwt
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersService
     */
    public async getCurrentUser(token: string): Promise<AxiosResponse> {
        let userId: string;
        if (!token) {
            userId = this.config.getOktaConfig().mockUserId;
            return this.getUserDetailsByUserID(userId);
        }
        const BEARER = "Bearer ";
        // eslint-disable-next-line no-param-reassign
        token = token.startsWith(BEARER) ? token.slice(BEARER.length) : token;
        const decoded = jwt.decode(token);
        const result = decoded.preferred_username;
        userId = result.split("@");
        return this.getUserDetailsByUserID(userId[0]);
    }

    /**
     * To login
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersService
     */
    public async login(token: string): Promise<AxiosResponse> {
        return this.getCurrentUser(token);
    }

    /**
     * To get the user details from MDR
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersController
     */
    private findUser(userId: string): Promise<AxiosResponse> {
        const mdrURL = this.config.getMdr().user.url;
        return this.httpService
            .get(`${mdrURL}${userId}`)
            .pipe(map((result) => result))
            .toPromise();
    }

    /**
     * To get the user details from MDR
     *
     * @param {*} Param
     * @returns
     * @memberof MDRUsersController
     */
    private findUserByEmailIds(emailids: string): Promise<AxiosResponse> {
        const mdrURL = this.config.getMdr().user.url;
        return this.httpService
            .get(`${mdrURL}?emailids=${emailids}`)
            .pipe(map((result) => result))
            .toPromise();
    }

    /**
     * get users details based on user list.
     *
     * @param {string} userIds
     * @returns {Promise<AxiosResponse>}
     * @memberof MDRUsersService
     */
    async findUserByUserIds(userIds: string): Promise<AxiosResponse> {
        const mdrURL = this.config.getMdr().user.url;
        const response = await this.httpService
            .get(`${mdrURL}?userids=${userIds}`)
            .pipe(map((result) => result))
            .toPromise();
        return response;
    }

    /**
     * get users details based on user list.
     *
     * @param {string} userIds
     * @returns {Promise<AxiosResponse>}
     * @memberof MDRUsersService
     */
    async getMultipleUserDetailsByUserIds(userIds: string): Promise<AxiosResponse> {
        if (!userIds) {
            throw new HttpException("Provide User Id(s)", HttpStatus.BAD_REQUEST);
        }
        const response = await this.findUserByUserIds(userIds);
        return response.data;
    }
}
